require("dotenv").config();

module.exports = {
  port: process.env.PORT || 4000,
  jwtSecret: process.env.JWT_SECRET || "dev-secret-change-me",
  jwtExpiresIn: "30d",
  dbPath: process.env.DB_PATH || "./data/shutt.db",
};
