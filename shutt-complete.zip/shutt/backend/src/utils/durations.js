// Single source of truth for shutt durations, nudge durations, and pricing.
// The server validates against these instead of trusting raw millisecond
// values from the client, so a client can't spoof "1 hour" while sending
// "1 year" worth of ms to dodge the Premium check.

const SEC = 1000;
const MIN = 60 * SEC;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;
const WEEK = 7 * DAY;

const DURATIONS = [
  { key: "15s", label: "15 seconds", ms: 15 * SEC, premium: false },
  { key: "30s", label: "30 seconds", ms: 30 * SEC, premium: false },
  { key: "60s", label: "60 seconds", ms: 60 * SEC, premium: false },
  { key: "1m", label: "1 minute", ms: 1 * MIN, premium: false },
  { key: "5m", label: "5 minutes", ms: 5 * MIN, premium: false },
  { key: "10m", label: "10 minutes", ms: 10 * MIN, premium: false },
  { key: "15m", label: "15 minutes", ms: 15 * MIN, premium: false },
  { key: "30m", label: "30 minutes", ms: 30 * MIN, premium: false },
  { key: "1h", label: "1 hour", ms: 1 * HOUR, premium: false },
  { key: "2h", label: "2 hours", ms: 2 * HOUR, premium: false },
  { key: "3h", label: "3 hours", ms: 3 * HOUR, premium: false },
  { key: "5h", label: "5 hours", ms: 5 * HOUR, premium: false },
  { key: "8h", label: "8 hours", ms: 8 * HOUR, premium: false },
  { key: "12h", label: "12 hours", ms: 12 * HOUR, premium: false },
  { key: "1d", label: "1 day", ms: 1 * DAY, premium: false },
  { key: "2d", label: "2 days", ms: 2 * DAY, premium: false },
  { key: "3d", label: "3 days", ms: 3 * DAY, premium: false },
  { key: "1w", label: "1 week", ms: 1 * WEEK, premium: false },
  { key: "2w", label: "2 weeks", ms: 2 * WEEK, premium: true },
  { key: "3w", label: "3 weeks", ms: 3 * WEEK, premium: true },
  { key: "1mo", label: "1 month", ms: 30 * DAY, premium: true },
  { key: "1y", label: "1 year", ms: 365 * DAY, premium: true },
];

const NUDGE_DURATIONS = [
  { key: "5m", label: "5 min", ms: 5 * MIN },
  { key: "10m", label: "10 min", ms: 10 * MIN },
  { key: "15m", label: "15 min", ms: 15 * MIN },
  { key: "30m", label: "30 min", ms: 30 * MIN },
  { key: "1h", label: "1 hour", ms: 1 * HOUR },
];

const PREMIUM_PRICE = 5;
const EMERGENCY_PRICE = 3;

// Exactly 7 days — the free/Premium line. Durations at or under this are
// free for everyone; anything longer needs Premium. Also used to decide
// whether an emergency unlock is free: bailing out of a free-tier (≤1 week)
// shutt costs nothing, since it was never a paid restriction to begin with.
const FREE_DURATION_LIMIT_MS = WEEK;

function findDuration(key) {
  return DURATIONS.find((d) => d.key === key) || null;
}

function findNudgeDuration(key) {
  return NUDGE_DURATIONS.find((d) => d.key === key) || null;
}

module.exports = {
  DURATIONS,
  NUDGE_DURATIONS,
  PREMIUM_PRICE,
  EMERGENCY_PRICE,
  FREE_DURATION_LIMIT_MS,
  findDuration,
  findNudgeDuration,
};
