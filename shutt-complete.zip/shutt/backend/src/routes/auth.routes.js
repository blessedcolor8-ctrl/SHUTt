const express = require("express");
const asyncHandler = require("../utils/asyncHandler");
const authService = require("../services/authService");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

router.post(
  "/signup",
  asyncHandler(async (req, res) => {
    const { email, password, name } = req.body || {};
    if (!email || !password || password.length < 6) {
      return res.status(400).json({ error: "Email and a password of at least 6 characters are required" });
    }
    if (!name || !String(name).trim()) {
      return res.status(400).json({ error: "Name is required" });
    }
    const result = authService.signup(String(email).toLowerCase().trim(), password, String(name).trim());
    res.status(201).json(result);
  })
);

router.post(
  "/login",
  asyncHandler(async (req, res) => {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: "Email and password are required" });
    const result = authService.login(String(email).toLowerCase().trim(), password);
    res.json(result);
  })
);

router.get(
  "/me",
  requireAuth,
  asyncHandler(async (req, res) => {
    res.json(authService.me(req.userId));
  })
);

router.patch(
  "/password",
  requireAuth,
  asyncHandler(async (req, res) => {
    const { currentPassword, newPassword } = req.body || {};
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: "currentPassword and newPassword are required" });
    }
    const result = authService.changePassword(req.userId, currentPassword, newPassword);
    res.json(result);
  })
);

router.post(
  "/forgot-password",
  asyncHandler(async (req, res) => {
    const { email } = req.body || {};
    if (!email) return res.status(400).json({ error: "Email is required" });
    const result = authService.requestPasswordReset(String(email).toLowerCase().trim());
    res.json(result);
  })
);

router.post(
  "/reset-password",
  asyncHandler(async (req, res) => {
    const { email, token, newPassword } = req.body || {};
    if (!email || !token || !newPassword) {
      return res.status(400).json({ error: "email, token and newPassword are required" });
    }
    const result = authService.resetPassword(String(email).toLowerCase().trim(), String(token).trim(), newPassword);
    res.json(result);
  })
);

module.exports = router;
