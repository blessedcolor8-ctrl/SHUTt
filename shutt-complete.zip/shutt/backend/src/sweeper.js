const db = require("./db");
const shuttService = require("./services/shuttService");
const sessionService = require("./services/sessionService");

// The routes also sweep lazily on read, so nothing ever looks stale to a
// client that's polling. This interval just means expiry notifications
// (an app being "available again") fire close to on-time even if nobody's
// actively hitting the API right when the timer runs out.
function startSweeper(intervalMs = 15000) {
  return setInterval(() => {
    const users = db.prepare(`SELECT id FROM users`).all();
    for (const u of users) {
      try {
        shuttService.sweepExpired(u.id);
        sessionService.sweepExpiredSessions(u.id);
      } catch (err) {
        console.error("sweeper error for user", u.id, err);
      }
    }
  }, intervalMs);
}

module.exports = { startSweeper };
