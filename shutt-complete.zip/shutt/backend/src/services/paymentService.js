const crypto = require("crypto");
const db = require("../db");
const { PREMIUM_PRICE, EMERGENCY_PRICE } = require("../utils/durations");
const notifications = require("./notificationService");

// These charges are simulated — there's no real card on file. The shape is
// deliberately kept close to what a Stripe integration would need
// (amount, type, a related record id) so swapping logPayment's internals
// for a real `stripe.paymentIntents.create(...)` call later is a small,
// contained change rather than a rewrite.
function logPayment(userId, type, amount, relatedId) {
  const id = crypto.randomUUID();
  db.prepare(
    `INSERT INTO payments (id, user_id, type, amount, related_id, created_at) VALUES (?, ?, ?, ?, ?, ?)`
  ).run(id, userId, type, amount, relatedId || null, Date.now());
  return id;
}

function listPayments(userId) {
  return db.prepare(`SELECT * FROM payments WHERE user_id = ? ORDER BY created_at DESC`).all(userId);
}

function unlockPremium(userId) {
  db.prepare(`UPDATE users SET is_premium = 1 WHERE id = ?`).run(userId);
  logPayment(userId, "premium", PREMIUM_PRICE, null);
  notifications.push(userId, "premium", `Premium unlocked — $${PREMIUM_PRICE} charged`);
}

module.exports = { logPayment, listPayments, unlockPremium, PREMIUM_PRICE, EMERGENCY_PRICE };
