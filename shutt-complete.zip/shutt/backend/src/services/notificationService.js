const crypto = require("crypto");
const db = require("../db");

function push(userId, kind, title) {
  const id = crypto.randomUUID();
  db.prepare(
    `INSERT INTO notifications (id, user_id, kind, title, read, created_at) VALUES (?, ?, ?, ?, 0, ?)`
  ).run(id, userId, kind, title, Date.now());
  return id;
}

function list(userId) {
  return db.prepare(`SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC`).all(userId);
}

function markAllRead(userId) {
  db.prepare(`UPDATE notifications SET read = 1 WHERE user_id = ? AND read = 0`).run(userId);
}

function unreadCount(userId) {
  return db.prepare(`SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND read = 0`).get(userId).c;
}

module.exports = { push, list, markAllRead, unreadCount };
