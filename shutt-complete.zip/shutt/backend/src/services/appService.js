const crypto = require("crypto");
const db = require("../db");

// A curated catalog of real, well-known apps a user can pick from to
// "import" into their account. Browsers have no API to read a phone's
// actual installed-app list (no site can, on iOS or Android — it's a
// privacy boundary, not a gap in this project), so this catalog is the
// honest substitute: real apps, not placeholders, picked by the user
// instead of auto-seeded. iconKey is a string the client maps to its own
// icon component; color is each app's real, recognizable brand color.
const APP_CATALOG = [
  { id: "whatsapp", name: "WhatsApp", category: "Messaging", color: "#25D366", iconKey: "message-circle" },
  { id: "messenger", name: "Messenger", category: "Messaging", color: "#00B2FF", iconKey: "send" },
  { id: "telegram", name: "Telegram", category: "Messaging", color: "#29A9EB", iconKey: "send" },
  { id: "signal", name: "Signal", category: "Messaging", color: "#3A76F0", iconKey: "message-circle" },
  { id: "instagram", name: "Instagram", category: "Social", color: "#C13584", iconKey: "camera" },
  { id: "facebook", name: "Facebook", category: "Social", color: "#1877F2", iconKey: "users" },
  { id: "x", name: "X", category: "Social", color: "#000000", iconKey: "at-sign" },
  { id: "snapchat", name: "Snapchat", category: "Social", color: "#FFFC00", iconKey: "camera" },
  { id: "reddit", name: "Reddit", category: "Social", color: "#FF4500", iconKey: "hash" },
  { id: "linkedin", name: "LinkedIn", category: "Social", color: "#0A66C2", iconKey: "briefcase" },
  { id: "pinterest", name: "Pinterest", category: "Social", color: "#E60023", iconKey: "camera" },
  { id: "tiktok", name: "TikTok", category: "Entertainment", color: "#010101", iconKey: "music-2" },
  { id: "youtube", name: "YouTube", category: "Entertainment", color: "#FF0000", iconKey: "play" },
  { id: "netflix", name: "Netflix", category: "Entertainment", color: "#E50914", iconKey: "film" },
  { id: "disney-plus", name: "Disney+", category: "Entertainment", color: "#113CCF", iconKey: "play" },
  { id: "twitch", name: "Twitch", category: "Entertainment", color: "#9146FF", iconKey: "play" },
  { id: "spotify", name: "Spotify", category: "Music", color: "#1DB954", iconKey: "music" },
  { id: "apple-music", name: "Apple Music", category: "Music", color: "#FA243C", iconKey: "music" },
  { id: "soundcloud", name: "SoundCloud", category: "Music", color: "#FF5500", iconKey: "music" },
  { id: "candy-crush", name: "Candy Crush", category: "Games", color: "#FF6FA5", iconKey: "gamepad-2" },
  { id: "clash-royale", name: "Clash Royale", category: "Games", color: "#6A3DE8", iconKey: "gamepad-2" },
  { id: "pubg-mobile", name: "PUBG Mobile", category: "Games", color: "#3E4C59", iconKey: "gamepad-2" },
  { id: "minecraft", name: "Minecraft", category: "Games", color: "#4E9A2A", iconKey: "gamepad-2" },
  { id: "gmail", name: "Gmail", category: "Productivity", color: "#EA4335", iconKey: "mail" },
  { id: "slack", name: "Slack", category: "Productivity", color: "#4A154B", iconKey: "briefcase" },
  { id: "notion", name: "Notion", category: "Productivity", color: "#111111", iconKey: "briefcase" },
  { id: "amazon", name: "Amazon", category: "Shopping", color: "#FF9900", iconKey: "shopping-cart" },
  { id: "ebay", name: "eBay", category: "Shopping", color: "#E53238", iconKey: "shopping-cart" },
  { id: "paypal", name: "PayPal", category: "Finance", color: "#003087", iconKey: "wallet" },
  { id: "cash-app", name: "Cash App", category: "Finance", color: "#00C244", iconKey: "wallet" },
  { id: "google-maps", name: "Google Maps", category: "Maps", color: "#1A73E8", iconKey: "map-pin" },
  { id: "uber", name: "Uber", category: "Maps", color: "#000000", iconKey: "map-pin" },
];

function getCatalog() {
  return APP_CATALOG;
}

function listAppsForUser(userId) {
  return db.prepare(`SELECT * FROM apps WHERE user_id = ? ORDER BY created_at ASC`).all(userId);
}

function getApp(userId, appId) {
  return db.prepare(`SELECT * FROM apps WHERE id = ? AND user_id = ?`).get(appId, userId);
}

function createApp(userId, { name, category, color, iconKey }) {
  const id = crypto.randomUUID();
  db.prepare(
    `INSERT INTO apps (id, user_id, name, category, color, icon_key, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(id, userId, name, category || "", color || "#8B8D93", iconKey || "app-window", Date.now());
  return getApp(userId, id);
}

// Bulk-adds selected catalog apps for a user in one transaction, skipping
// anything they've already added (by name, case-insensitive) so importing
// twice is harmless.
function importApps(userId, catalogIds) {
  const already = new Set(listAppsForUser(userId).map((a) => a.name.toLowerCase()));
  const toAdd = APP_CATALOG.filter((c) => catalogIds.includes(c.id) && !already.has(c.name.toLowerCase()));
  const insert = db.prepare(
    `INSERT INTO apps (id, user_id, name, category, color, icon_key, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`
  );
  const now = Date.now();
  const tx = db.transaction((apps) => {
    for (const a of apps) insert.run(crypto.randomUUID(), userId, a.name, a.category, a.color, a.iconKey, now);
  });
  tx(toAdd);
  return listAppsForUser(userId);
}

module.exports = { getCatalog, importApps, listAppsForUser, getApp, createApp };
