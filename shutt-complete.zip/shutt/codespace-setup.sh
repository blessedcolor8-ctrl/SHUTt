#!/bin/bash
# Shutt APK build environment for GitHub Codespaces (Ubuntu).
# Run ONCE from the repo root (the folder containing mobile/, backend/,
# shutt-android-engine/):  bash codespace-setup.sh
# Idempotent: safe to re-run. Ends by printing exact next steps.
set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"
export ANDROID_HOME="$HOME/Android/Sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

echo "==> 1/6 Java 17 (needed by Android Gradle Plugin 8.x)"
if java -version 2>&1 | grep -q "17\."; then
  echo "    Java 17 already active."
else
  sudo apt-get update -qq
  sudo apt-get install -y -qq openjdk-17-jdk-headless
fi
export JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(which java)")")")"
java -version 2>&1 | head -1

echo "==> 2/6 Node dependencies"
node --version
(cd "$ROOT/backend" && npm install)
(cd "$ROOT/mobile" && npm install)
(cd "$ROOT/shutt-android-engine/plugin" && npm install --no-save 2>/dev/null || npm install)

echo "==> 3/6 Android SDK (cmdline-tools, platform 34, build-tools)"
mkdir -p "$ANDROID_HOME/cmdline-tools"
if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
  cd /tmp
  curl -sSL -o cmdtools.zip "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
  rm -rf "$ANDROID_HOME/cmdline-tools/latest"
  unzip -q cmdtools.zip -d "$ANDROID_HOME/cmdline-tools/"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
  rm cmdtools.zip
  cd "$ROOT"
fi
yes | sdkmanager --licenses > /dev/null 2>&1 || true
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

echo "==> 4/6 backend env file"
if [ ! -f "$ROOT/backend/.env" ]; then
  cp "$ROOT/backend/.env.example" "$ROOT/backend/.env"
  echo "    created backend/.env from example (edit PORT/JWT secret if you like)"
fi

echo "==> 5/6 enforcer plugin + native project"
(cd "$ROOT/mobile" && npm install ../shutt-android-engine/plugin)
if [ ! -d "$ROOT/mobile/android" ]; then
  (cd "$ROOT/mobile" && npx cap add android)
else
  echo "    mobile/android already exists, skipping 'cap add android'"
fi
echo "sdk.dir=$ANDROID_HOME" > "$ROOT/mobile/android/local.properties"
mkdir -p "$HOME/.gradle"
if ! grep -q "org.gradle.jvmargs" "$HOME/.gradle/gradle.properties" 2>/dev/null; then
  echo "org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8" >> "$HOME/.gradle/gradle.properties"
fi

echo "==> 6/6 sync web bundle into the native project"
(cd "$ROOT/mobile" && npm run cap:sync)

echo ""
echo "================================================================"
echo " Environment ready. Next steps (give these to your build agent,"
echo " or see CODESPACE_PROMPT.md):"
echo "  1. Merge the manifest block from shutt-android-engine/README.md"
echo "     into mobile/android/app/src/main/AndroidManifest.xml, copy the"
echo "     two res/xml files, and add the two strings (see P5 in"
echo "     shutt-android-engine/web/patches.md)."
echo "  2. Start the backend:  (cd backend && npm run dev)"
echo "     Forward port 4000 as PUBLIC, copy its https URL."
echo "  3. Build:  (cd mobile && npx cap open android  -> no; headless:)"
echo "       cd mobile/android && ./gradlew assembleDebug"
echo "     APK lands at:"
echo "       mobile/android/app/build/outputs/apk/debug/app-debug.apk"
echo "  4. Download the APK, install on your phone, paste the backend URL"
echo "     into the app's red phone-button sheet -> Backend -> Save."
echo "================================================================"
