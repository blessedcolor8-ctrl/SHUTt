# shutt — full project archive

Everything built across this project, organized into one place.

## What's in here

```
frontend/
  shutt.jsx         The React source — this is what renders as the
                     interactive prototype in Claude. Onboarding, home,
                     shutt/lock flow, notifications, settings, coffee tips,
                     all of it, in one self-contained component.

web-app/            A standalone, installable version of the same app.
  index.html          Compiled from shutt.jsx — open this directly in any
                       browser, or host it to get a real HTTPS URL.
  manifest.json        Makes it installable as a PWA (Add to Home Screen).
  sw.js                 Service worker — required for Chrome's install prompt.
  icon-192.png,
  icon-512.png,
  icon-180.png            App icons generated from your logo.

backend/            A real Express + SQLite API — auth, shutts with
                     per-app durations, Premium/Emergency payments,
                     notifications. See backend/README.md for setup
                     and the full API reference.

assets/
  logo-original.png   The logo you uploaded, at full resolution.

mobile/             A Capacitor Android wrapper around web-app/ — the
                     path to a real, installable .apk. See mobile/README.md
                     for exact build steps; that step needs your own
                     machine (Android SDK + network), not this archive.
```

## Frontend ↔ backend, now wired together

`frontend/shutt.jsx` (and the compiled `web-app/index.html`) no longer hold
any local mock state for apps, shutts, notifications, or payments — every
screen reads from and writes to the real backend at `API_BASE`
(`http://localhost:4000/api` on web by default; it auto-switches to
`10.0.2.2` when running inside the Android wrapper in `mobile/` — see
`resolveApiBase()` near the top of `shutt.jsx`). That includes:

- **Auth** — real signup/login/`me` calls, JWT kept in memory and, where
  available, `localStorage` (degrades to session-only if storage is blocked).
  Signup now also collects a name (small backend addition — see below) so
  the home screen can greet you by it.
- **Apps & shutts** — `GET /api/apps` drives both the Home and Apps tabs,
  including live lock status; setting a restriction is a real
  `POST /api/shutts` with a duration key pulled from `GET /api/meta`, grouped
  into Seconds/Minutes/Hours/Days tabs in the sheet.
- **Restriction detail** — a dedicated screen per locked app with a real,
  live countdown from the server's `unlockAt`, plus a working emergency
  unlock (`POST /api/shutts/:id/emergency-unlock`).
- **Stats** — the Day/Week/Month/Year chart and "Most restricted" list are
  computed client-side from actual shutt history via a new
  `GET /api/shutts` (all statuses) endpoint — there's no invented "screen
  time saved" number anywhere, since the backend has no way to measure that.
- **Notifications & billing** — real `GET /api/notifications` /
  `POST /api/notifications/read-all`, and a real billing history from
  `GET /api/payments`.
- **Adding an app** — the Apps tab has a working "add app" sheet
  (`POST /api/apps`) with an icon/color picker; if you leave the category
  blank it's guessed client-side from the name rather than left empty.

Small, additive backend changes that came with this: `users.name` (schema +
signup), a `PATCH /api/auth/password` endpoint (backs the real "Change
password" flow in Settings), a `GET /api/shutts` history endpoint, and finer
duration presets (seconds and single-digit minutes) in `utils/durations.js`
so the unit picker has something real to show in every tab. Nothing existing
was removed or renamed.

Every row and button in the UI now does something real: the Apps search box
filters live, "Notifications" and "Manage tracked apps" in Settings jump to
working screens, and "Security" opens a real change-password form wired to
the new endpoint. The app's actual uploaded logo (the same PNG already used
to generate the PWA icons) is embedded directly in `shutt.jsx` — as the boot
splash, the auth screen mark, and a small brand mark on every onboarding
slide — so there's no placeholder icon anywhere in the flow.

## Known gap between frontend and backend

The frontend's usage-nudge feature (the "set a time limit when you open an
app" popup) was removed in a later revision. The backend's
`src/routes/sessions.routes.js` and `src/services/sessionService.js` still
implement that feature server-side — they were never removed from the
backend since that wasn't asked for separately. They're harmless to leave in
place (nothing calls them if the frontend never hits those endpoints), but
worth knowing about if you go to wire the two together, since it means the
backend currently models a bit more than the frontend actually uses.

## Getting each piece running

- **frontend/shutt.jsx** — paste into a Claude conversation to keep
  iterating on it as an artifact, or drop into any React + Tailwind +
  lucide-react project.
- **web-app/** — open `index.html` directly, or host the whole folder
  (Netlify Drop, Vercel, GitHub Pages) for a real URL you can install on
  a phone or package into an Android APK via PWABuilder.
- **backend/** — `cd backend && npm install && cp .env.example .env && npm run dev`.
