# shutt — Android wrapper (Capacitor)

This turns the existing web app (`../web-app`) into a real, installable
Android app using [Capacitor](https://capacitorjs.com/) — a native shell
with a WebView inside, not a from-scratch rewrite. Nothing in
`frontend/shutt.jsx` or the backend changes; this folder just wraps it.

## Why Capacitor instead of just "installing the PWA"

You could also install `web-app/` as a PWA straight from Chrome ("Add to
Home Screen") with zero setup — it already has a manifest, icons, and a
service worker. That's the fastest way to get *something* on your phone.

Capacitor is the better foundation if shutt is ever going to do what the
original project doc describes — actually overlaying/blocking other apps.
That needs real native Android APIs (`AccessibilityService`,
`UsageStatsManager`, Device Admin), which a plain PWA can never get access
to. Capacitor gives you a real native project you can add custom Java/Kotlin
plugins to later; a PWA install does not.

## What I can't do for you

I don't have network access or the Android SDK/Gradle available where this
was generated, so I can't run `npx cap add android` or compile an actual
`.apk` here — that step genuinely needs your machine. Everything in this
folder is what's left after that: real, working config, pre-built into
place where I could, so the remaining steps are copy-paste.

## Prerequisites (one-time)

- [Android Studio](https://developer.android.com/studio) installed — this
  gives you the Android SDK, an emulator, and Gradle, all in one installer.
- Node.js (already required for the rest of this project).

## Steps

**1. Install dependencies**
```bash
cd mobile
npm install
```

**2. Start the real backend** (in a separate terminal — the app has
nothing to show without it)
```bash
cd ../backend
npm install
cp .env.example .env
npm run dev
```

**3. Generate the native Android project**

This is the one step that needs your machine's network access, since it
downloads Capacitor's Android template:
```bash
npx cap add android
```
This creates an `android/` folder here with a full Gradle project.

**4. Allow local dev traffic (one-time)**

The backend runs on plain HTTP, which Android blocks by default. Create
`android/app/src/main/res/xml/network_security_config.xml` with:
```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <domain-config cleartextTrafficPermitted="true">
        <domain includeSubdomains="false">10.0.2.2</domain>
        <domain includeSubdomains="false">localhost</domain>
    </domain-config>
</network-security-config>
```
Then in `android/app/src/main/AndroidManifest.xml`, add one attribute to
the `<application>` tag:
```xml
<application
    android:networkSecurityConfig="@xml/network_security_config"
    ... (leave everything else as-is) ...>
```
(Skip this step entirely once you point `NATIVE_HOST` in
`frontend/shutt.jsx` at a real HTTPS backend — this is only needed for
plain-HTTP local development.)

**5. Build and run**

Easiest — opens Android Studio, then just click the Run button with an
emulator or a USB-debugging phone selected:
```bash
npm run android:open
```

Or, to get an actual standalone `.apk` file you can share or sideload:
```bash
npm run android:debug-apk
```
The file lands at `android/app/build/outputs/apk/debug/app-debug.apk`.
Install it with `adb install app-debug.apk`, or copy it to the phone and
open it (Android will prompt to allow installs from that source).

## If you're testing on a real phone, not the emulator

`frontend/shutt.jsx` defaults `NATIVE_HOST` to `10.0.2.2`, which is a magic
address that **only works in the Android emulator**. For a physical phone,
either:
- run `adb reverse tcp:4000 tcp:4000` and change `NATIVE_HOST` to
  `"localhost"`, or
- change `NATIVE_HOST` to your computer's LAN IP (e.g. `192.168.1.23`) and
  make sure the phone is on the same WiFi network.

After changing it, re-run `npm run cap:sync` (or `android:open` /
`android:debug-apk`, which call it for you) so the rebuilt web bundle gets
copied into the native project.

## Keeping this in sync

`www/` here is a straight copy of `../web-app` (via `build-www.js`) — it's
not hand-edited. Whenever `frontend/shutt.jsx` changes and
`web-app/index.html` gets recompiled from it, just re-run `npm run
cap:sync` before your next build; you never need to touch `www/` directly.
