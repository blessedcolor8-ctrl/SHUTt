// shutt-device-ui.js — floating "On this device" setup + import sheet.
// Load as a MODULE script after shutt-enforcer-bridge.js:
//   <script type="module" src="./shutt-device-ui.js"></script>
//
// Why a separate module: it imports React from the SAME esm.sh URLs as the
// main bundle, so it shares the one React instance, and mounts its own tiny
// tree (floating button + sheet) in a second React root. Zero edits to the
// compiled bundle, zero JSX recompilation.
//
// Visible ONLY inside the native Android app — except when the URL has
// ?deviceui=1 (debug preview, talks to window.ShuttMock). Invisible
// otherwise: the browser build is byte-identical and unaffected.

import React, { useState, useEffect } from "https://esm.sh/react@18.3.1";
import { jsx as _jsx, jsxs as _jsxs } from "https://esm.sh/react@18.3.1/jsx-runtime";
import { createRoot } from "https://esm.sh/react-dom@18.3.1/client";
import {
  Smartphone, X, Search, CheckCircle2, Loader2, ShieldCheck,
} from "https://esm.sh/lucide-react@0.383.0?deps=react@18.3.1";

const C = {
  ink: "#141414", paper: "#FFFFFF", off: "#F6F4F2",
  red: "#E01B22", steel: "#75726F", steel2: "#A9A6A2",
  line: "#E7E3DF", green: "#0F8A4B",
};
const FONT = "'Roboto','Segoe UI',system-ui,-apple-system,Arial,sans-serif";
const TOKEN_KEY = "shutt_token";
const HOST_KEY = "shutt_backend_host";
const BASE_KEY = "shutt_backend_base";

function ls(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
function bridge() { return window.ShuttEnforcerBridge || null; }
function isNative() {
  try {
    const B = bridge();
    return !!(B && B.isNative && B.isNative());
  } catch (e) { return false; }
}
function apiBase() {
  const full = ls(BASE_KEY);
  if (full) return String(full).replace(/\/+$/, "");
  return "http://" + (ls(HOST_KEY) || "10.0.2.2") + ":4000/api";
}
function token() { return ls(TOKEN_KEY); }

async function apiFetch(path, opts) {
  opts = opts || {};
  const t = token();
  if (!t) throw new Error("Not signed in");
  if (window.ShuttMock) { // debug preview path (?deviceui=1 in browser)
    return window.ShuttMock.apiCall(path, { method: opts.method || "GET", body: opts.body, token: t });
  }
  const res = await fetch(apiBase() + path, {
    method: opts.method || "GET",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + t },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error((data && data.error) || ("Request failed (" + res.status + ")"));
  return data;
}

function guessCategory(name) {
  const n = String(name || "").toLowerCase();
  if (/whatsapp|telegram|signal|messenger|message|sms|chat|discord|wechat|line\b|viber/.test(n)) return "Messaging";
  if (/insta|face|tiktok|x\b|twitter|snap|reddit|linked|pinterest|threads/.test(n)) return "Social";
  if (/youtube|netflix|twitch|disney|hulu|prime video|hotstar|movie|video|player/.test(n)) return "Entertainment";
  if (/spotify|music|sound|audio|podcast|tune/.test(n)) return "Music";
  if (/candy|clash|pubg|minecraft|game|chess|ludo|puzzle|royale|craft/.test(n)) return "Games";
  if (/gmail|mail|slack|notion|docs|drive|office|calendar|notes|todo|task/.test(n)) return "Productivity";
  if (/amazon|shop|ebay|store|cart|flipkart|aliexpress/.test(n)) return "Shopping";
  if (/pay|bank|cash|wallet|upi|money|finance/.test(n)) return "Finance";
  if (/map|uber|lyft|ola|taxi|travel|flight|hotel/.test(n)) return "Maps";
  return "Imported";
}

function StepBtn({ label, done, onClick }) {
  return _jsx("button", {
    onClick: onClick,
    style: {
      height: 44, borderRadius: 12, border: "none",
      background: done ? C.green : C.red, color: "#fff",
      fontFamily: FONT, fontWeight: 800, fontSize: 13.5,
      cursor: "pointer", padding: "0 16px",
    },
    children: (done ? "✓ " : "") + label,
  });
}

function DeviceUI() {
  const params = new URLSearchParams(window.location.search || "");
  const [forced, setForced] = useState(params.get("deviceui") === "1");
  const [open, setOpen] = useState(false);
  const [status, setStatus] = useState(null);
  const [host, setHostInput] = useState(() => { const B = bridge(); return B ? B.getHost() : "10.0.2.2"; });
  const [deviceApps, setDeviceApps] = useState([]);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState({});
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  const visible = forced || isNative();
  useEffect(() => {
    window.ShuttDeviceUI = Object.assign(window.ShuttDeviceUI || {}, {
      open: () => { setForced(true); setOpen(true); },
      _forceShow: () => { setForced(true); setOpen(true); },
    });
  }, []);

  useEffect(() => {
    if (!visible) return;
    let alive = true;
    const B = bridge();
    const load = () => {
      if (B && B.getStatus) B.getStatus().then((s) => { if (alive) setStatus(s); }).catch(() => {});
      if (B && B.listInstalledApps) {
        B.listInstalledApps().then((r) => { if (alive) setDeviceApps((r && r.apps) || []); }).catch(() => {});
      }
    };
    load();
    const t = setInterval(load, 5000);
    return () => { alive = false; clearInterval(t); };
  }, [visible]);

  if (!visible) return null;

  const saveHost = () => {
    const B = bridge();
    if (B) B.setHost(host);
    setMsg("Backend saved. Locks sync to it within seconds.");
    setTimeout(() => setMsg(""), 3000);
  };

  const q = query.trim().toLowerCase();
  const list = deviceApps.filter((d) => !q || String(d.label || "").toLowerCase().includes(q));
  const entries = Object.values(selected);

  const toggle = (pkg) => setSelected((prev) => {
    const next = { ...prev };
    if (next[pkg]) { delete next[pkg]; return next; }
    const found = deviceApps.find((d) => d.packageName === pkg);
    if (found) next[pkg] = found;
    return next;
  });

  const doImport = async () => {
    if (!entries.length || busy) return;
    setBusy(true);
    setMsg("");
    const B = bridge();
    let ok = 0;
    try {
      for (const e of entries) {
        try {
          await apiFetch("/apps", {
            method: "POST",
            body: { name: e.label, category: guessCategory(e.label), color: "#141414", iconKey: "smartphone" },
          });
        } catch (err) { /* name may already exist — mapping below still applies */ }
        if (B) B.saveDeviceMapping(e.label, e.packageName);
        ok++;
      }
      setMsg(ok + " app" + (ok === 1 ? "" : "s") + " imported — real blocking is armed.");
      setSelected({});
      if (B && B.syncNow) B.syncNow();
    } catch (e) {
      setMsg(e.message || "Import failed");
    } finally {
      setBusy(false);
    }
  };

  const native = isNative();
  const needA11y = !status || !status.accessibilityEnabled;

  return _jsxs(React.Fragment, {
    children: [
      _jsx("button", {
        key: "fab",
        onClick: () => setOpen(true),
        title: "On this device",
        style: {
          position: "fixed", right: 16, bottom: 96, width: 56, height: 56,
          borderRadius: "50%", border: "none", background: C.red, color: "#fff",
          display: "flex", alignItems: "center", justifyContent: "center",
          cursor: "pointer", zIndex: 9999,
          boxShadow: "0 4px 16px rgba(0,0,0,0.3)",
        },
        children: _jsx(Smartphone, { size: 24, strokeWidth: 2.4 }),
      }),
      open && _jsxs("div", {
        key: "sheet",
        style: {
          position: "fixed", inset: 0, zIndex: 10000,
          display: "flex", flexDirection: "column", justifyContent: "flex-end",
        },
        children: [
          _jsx("div", {
            key: "bg", onClick: () => setOpen(false),
            style: { position: "absolute", inset: 0, background: "rgba(20,20,20,0.55)" },
          }),
          _jsxs("div", {
            key: "card",
            style: {
              position: "relative", background: C.paper, borderRadius: "26px 26px 0 0",
              padding: "10px 22px 20px", maxHeight: "88%", display: "flex", flexDirection: "column",
              maxWidth: 430, margin: "0 auto", width: "100%", boxSizing: "border-box",
              fontFamily: FONT,
            },
            children: [
              _jsx("div", { key: "grab", style: { width: 40, height: 4, borderRadius: 2, background: C.line, margin: "6px auto 16px", flexShrink: 0 } }),
              _jsxs("div", {
                key: "head",
                style: { display: "flex", alignItems: "center", gap: 12, flexShrink: 0 },
                children: [
                  _jsxs("div", {
                    style: { flex: 1 },
                    children: [
                      _jsx("div", {
                        style: { fontWeight: 800, fontSize: 17, color: C.ink },
                        children: "On this device",
                      }),
                      _jsx("div", {
                        style: { fontWeight: 500, fontSize: 12.5, color: C.steel },
                        children: native ? "Protection status + real installed apps" : "Debug preview (browser data)",
                      }),
                    ],
                  }),
                  _jsx("button", {
                    onClick: () => setOpen(false),
                    style: { background: C.off, border: "none", borderRadius: 10, width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0 },
                    children: _jsx(X, { size: 17, color: C.ink, strokeWidth: 2.6 }),
                  }),
                ],
              }),
              _jsxs("div", {
                key: "setup",
                style: { marginTop: 14, borderRadius: 20, background: C.ink, padding: "16px", flexShrink: 0 },
                children: [
                  _jsxs("div", {
                    style: { display: "flex", alignItems: "center", gap: 8 },
                    children: [
                      _jsx(ShieldCheck, { size: 17, color: native ? C.red : C.steel2, strokeWidth: 2.4 }),
                      _jsx("div", {
                        style: { fontWeight: 800, fontSize: 14, color: "#fff" },
                        children: !native ? "Runs in the Android app" : needA11y ? "Protection is off" : "Protection on",
                      }),
                    ],
                  }),
                  _jsx("div", {
                    style: { fontWeight: 500, fontSize: 12, color: C.steel2, marginTop: 4, lineHeight: 1.5 },
                    children: "Blocking needs accessibility access. Without it, locks are tracked but apps still open.",
                  }),
                  _jsxs("div", {
                    style: { display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" },
                    children: [
                      _jsx(StepBtn, { key: "a", label: "Accessibility", done: !!(status && status.accessibilityEnabled), onClick: () => bridge() && bridge().openSettings("accessibility") }),
                      _jsx(StepBtn, { key: "u", label: "Usage access", done: !!(status && status.usageAccessGranted), onClick: () => bridge() && bridge().openSettings("usage") }),
                      _jsx(StepBtn, { key: "b", label: "Battery: don't optimize", done: !!(status && status.batteryExempt), onClick: () => bridge() && bridge().openSettings("battery") }),
                    ],
                  }),
                  _jsxs("div", {
                    style: { display: "flex", alignItems: "center", gap: 8, marginTop: 10 },
                    children: [
                      _jsx("div", {
                        style: { fontWeight: 700, fontSize: 12, color: C.steel2, flexShrink: 0 },
                        children: "Backend:",
                      }),
                      _jsx("input", {
                        value: host, onChange: (e) => setHostInput(e.target.value),
                        placeholder: "10.0.2.2, LAN IP, or Codespaces https URL",
                        style: { flex: 1, height: 40, borderRadius: 10, border: "1px solid #2C2C2C", background: "#1F1F1F", padding: "0 12px", fontFamily: FONT, fontSize: 13, color: "#fff", outline: "none", minWidth: 0 },
                      }),
                      _jsx("button", {
                        onClick: saveHost,
                        style: { height: 40, borderRadius: 10, border: "none", background: C.red, color: "#fff", fontFamily: FONT, fontWeight: 800, fontSize: 13, padding: "0 14px", cursor: "pointer", flexShrink: 0 },
                        children: "Save",
                      }),
                    ],
                  }),
                ],
              }),
              _jsxs("div", {
                key: "search",
                style: { marginTop: 14, display: "flex", alignItems: "center", gap: 10, background: C.off, border: "1px solid " + C.line, borderRadius: 14, padding: "0 14px", flexShrink: 0 },
                children: [
                  _jsx(Search, { size: 16, color: C.steel, strokeWidth: 2.4 }),
                  _jsx("input", {
                    value: query, onChange: (e) => setQuery(e.target.value),
                    placeholder: native ? "Search installed apps" : "Search (device list is native-only)",
                    style: { flex: 1, height: 42, border: "none", background: "none", outline: "none", fontFamily: FONT, fontSize: 14, fontWeight: 500, color: C.ink },
                  }),
                ],
              }),
              _jsx("div", {
                key: "list",
                style: { overflowY: "auto", flex: 1, marginTop: 8 },
                children: (!native || !list.length) ? _jsx("div", {
                  style: { padding: "20px 4px", textAlign: "center", fontWeight: 500, fontSize: 13, color: C.steel },
                  children: !native ? "Install the Android app to pick from real installed apps." : "No matching installed apps.",
                }) : list.map((d) => {
                  const sel = !!selected[d.packageName];
                  return _jsxs("button", {
                    key: d.packageName,
                    onClick: () => toggle(d.packageName),
                    style: { width: "100%", display: "flex", alignItems: "center", gap: 12, padding: "11px 4px", background: "none", border: "none", cursor: "pointer", textAlign: "left" },
                    children: [
                      _jsx("div", {
                        style: { width: 40, height: 40, borderRadius: 12, background: C.ink, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 },
                        children: _jsx("span", {
                          style: { fontWeight: 800, fontSize: 16, color: "#fff" },
                          children: String(d.label || "?").charAt(0).toUpperCase(),
                        }),
                      }),
                      _jsxs("div", {
                        style: { flex: 1 },
                        children: [
                          _jsx("div", {
                            style: { fontWeight: 700, fontSize: 14.5, color: C.ink },
                            children: d.label,
                          }),
                          _jsx("div", {
                            style: { fontWeight: 500, fontSize: 11.5, color: C.steel, marginTop: 1 },
                            children: d.packageName,
                          }),
                        ],
                      }),
                      sel
                        ? _jsx(CheckCircle2, { size: 24, color: C.red, strokeWidth: 2.2, style: { flexShrink: 0 } })
                        : _jsx("div", { style: { width: 22, height: 22, borderRadius: "50%", border: "2px solid " + C.line, flexShrink: 0 } }),
                    ],
                  });
                }),
              }),
              msg && _jsx("div", {
                key: "msg",
                style: { marginTop: 8, fontSize: 13, fontWeight: 700, color: C.green },
                children: msg,
              }),
              _jsxs("button", {
                key: "go",
                onClick: doImport, disabled: busy || !entries.length,
                style: {
                  marginTop: 12, width: "100%", height: 52, borderRadius: 16, border: "none",
                  background: !entries.length ? C.steel2 : C.red, color: "#fff",
                  fontFamily: FONT, fontWeight: 800, fontSize: 15,
                  cursor: !entries.length ? "default" : "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center", gap: 8, flexShrink: 0,
                },
                children: [
                  busy && _jsx(Loader2, { size: 16 }),
                  !entries.length ? "Select installed apps" : ("Import " + entries.length + " app" + (entries.length === 1 ? "" : "s")),
                ],
              }),
            ],
          }),
        ],
      }),
    ],
  });
}

window.ShuttDeviceUI = window.ShuttDeviceUI || {};
try {
  const mount = document.createElement("div");
  mount.id = "shutt-device-ui";
  document.body.appendChild(mount);
  createRoot(mount).render(React.createElement(DeviceUI));
} catch (e) {
  // never break the host app
  if (window.console) console.warn("device-ui mount failed", e);
}
