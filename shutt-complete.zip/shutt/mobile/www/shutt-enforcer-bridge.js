// Shutt native-enforcer bridge — load with:
//   <script src="./shutt-enforcer-bridge.js"></script>
// placed AFTER <div id="root"></div> and BEFORE the module script.
// (In this repo the file ships in web-app/ and mobile/www/ via build-www.js;
// the preview loads the same file from src/shutt-android/web/.)
//
// SELF-DRIVING: a 5s timer reads the app's own auth token (localStorage,
// same key the app uses) and the app list — from the real backend on-device,
// from window.ShuttMock in the browser preview — and pushes the locked set
// to the native plugin. No app-code hooks required for core syncing: login,
// locks, unlocks and logout all propagate automatically (logout removes the
// token, so the next tick finds nothing to sync).
//
// Extra API used by the setup banner + device-import sheet (see patches.md):
//   ShuttEnforcerBridge.isNative()
//   ShuttEnforcerBridge.getStatus() -> plugin status (or {isNative:false})
//   ShuttEnforcerBridge.openSettings("accessibility"|"usage"|"battery"|"admin")
//   ShuttEnforcerBridge.listInstalledApps()
//   ShuttEnforcerBridge.saveDeviceMapping(appName, packageName)
//   ShuttEnforcerBridge.getHost()/setHost(h)  (backend LAN IP for real devices)
//   ShuttEnforcerBridge.onBlockedAttempt(cb)
//   ShuttEnforcerBridge.syncNow()
(function () {
  "use strict";

  var TOKEN_KEY = "shutt_token";
  var HOST_KEY = "shutt_backend_host";
  var BASE_KEY = "shutt_backend_base";
  var MAP_KEY = "shutt_device_map_v1";

  // catalog name (lowercase) -> known Android packages (mirrors PackageCatalog.kt)
  var CATALOG = [
    ["whatsapp", ["com.whatsapp", "com.whatsapp.w4b"]],
    ["messenger", ["com.facebook.orca"]],
    ["telegram", ["org.telegram.messenger", "org.telegram.messenger.web"]],
    ["signal", ["org.thoughtcrime.securesms"]],
    ["instagram", ["com.instagram.android"]],
    ["facebook", ["com.facebook.katana"]],
    ["x", ["com.twitter.android"]],
    ["snapchat", ["com.snapchat.android"]],
    ["reddit", ["com.reddit.frontpage"]],
    ["linkedin", ["com.linkedin.android"]],
    ["pinterest", ["com.pinterest"]],
    ["tiktok", ["com.zhiliaoapp.musically", "com.ss.android.ugc.trill"]],
    ["youtube", ["com.google.android.youtube"]],
    ["netflix", ["com.netflix.mediaclient"]],
    ["disney+", ["com.disney.disneyplus"]],
    ["twitch", ["tv.twitch.android.app"]],
    ["spotify", ["com.spotify.music"]],
    ["apple music", ["com.apple.android.music"]],
    ["soundcloud", ["com.soundcloud.android"]],
    ["candy crush", ["com.king.candycrushsaga"]],
    ["clash royale", ["com.supercell.clashroyale"]],
    ["pubg mobile", ["com.tencent.ig"]],
    ["minecraft", ["com.mojang.minecraftpe"]],
    ["gmail", ["com.google.android.gm"]],
    ["slack", ["com.Slack"]],
    ["notion", ["notion.id"]],
    ["amazon", ["com.amazon.mShop.android.shopping"]],
    ["ebay", ["com.ebay.mobile"]],
    ["paypal", ["com.paypal.android.p2pmobile"]],
    ["cash app", ["com.squareup.cash"]],
    ["google maps", ["com.google.android.apps.maps"]],
    ["uber", ["com.ubercab"]]
  ];

  function store(k, v) { try { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} }
  function load(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }

  function plugin() {
    try {
      var C = window.Capacitor;
      if (C && C.isNativePlatform && C.isNativePlatform()) {
        return (C.Plugins && C.Plugins.ShuttEnforcer) || null;
      }
    } catch (e) {}
    return null;
  }

  function host() { return load(HOST_KEY) || "10.0.2.2"; } // emulator magic IP; real devices: set LAN IP
  function apiBase() {
    var full = load(BASE_KEY);
    if (full) return String(full).replace(/\/+$/, "");
    return "http://" + host() + ":4000/api";
  }
  function token() { return load(TOKEN_KEY); }

  function deviceMap() {
    try { return JSON.parse(load(MAP_KEY) || "{}"); } catch (e) { return {}; }
  }

  function fetchApps(t) {
    if (window.ShuttMock) { // browser preview (or any page with the mock)
      return window.ShuttMock.apiCall("/apps", { token: t }).catch(function () { return null; });
    }
    return fetch(apiBase() + "/apps", { headers: { Authorization: "Bearer " + t } })
      .then(function (r) { return r.ok ? r.json() : null; })
      .catch(function () { return null; });
  }

  var installedCache = { at: 0, list: [] };
  function installed(p) {
    var now = Date.now();
    if (now - installedCache.at < 60000 && installedCache.list.length) {
      return Promise.resolve(installedCache.list);
    }
    return p.listInstalledApps().then(function (r) {
      installedCache = { at: now, list: (r && r.apps) || [] };
      return installedCache.list;
    }).catch(function () { return []; });
  }

  function resolvePkg(app, inst) {
    var key = String(app.name || "").toLowerCase();
    var map = deviceMap();
    if (map[key]) return map[key];
    var pkgs = null;
    for (var i = 0; i < CATALOG.length; i++) {
      if (CATALOG[i][0] === key) { pkgs = CATALOG[i][1]; break; }
    }
    if (pkgs && inst.length) {
      for (var j = 0; j < pkgs.length; j++) {
        for (var k = 0; k < inst.length; k++) {
          if (inst[k].packageName === pkgs[j]) return pkgs[j];
        }
      }
    }
    if (inst.length) {
      for (var m = 0; m < inst.length; m++) {
        if (String(inst[m].label || "").toLowerCase() === key) return inst[m].packageName;
      }
    }
    return null;
  }

  var lastTokenSent = null;
  function tick() {
    var p = plugin();
    if (!p) return; // browser: nothing native to sync
    var t = token();
    if (!t) { lastTokenSent = null; return; } // logged out
    fetchApps(t).then(function (apps) {
      if (!apps) return;
      return installed(p).then(function (inst) {
        var locks = [];
        for (var i = 0; i < apps.length; i++) {
          var a = apps[i];
          if (!a || a.status !== "locked" || !a.unlockAt || !a.shuttId) continue;
          var pkg = resolvePkg(a, inst);
          if (!pkg) continue; // not installed / unmapped — backend still tracks it
          locks.push({ appId: a.id, shuttId: a.shuttId, packageName: pkg, label: a.name, unlockAt: a.unlockAt });
        }
        return p.syncLocks({ locks: locks }).catch(function () {});
      }).then(function () {
        if (lastTokenSent !== t) {
          lastTokenSent = t;
          return p.setAuthToken({ token: t, apiBase: apiBase() }).catch(function () {});
        }
      });
    }).catch(function () {});
  }

  window.ShuttEnforcerBridge = {
    isNative: function () { return !!plugin(); },
    getHost: function () { return load(BASE_KEY) || host(); },
    setHost: function (h) {
      h = String(h || "").trim().replace(/\/+$/, "");
      if (/^https?:\/\//i.test(h)) { store(BASE_KEY, h); }
      else { store(BASE_KEY, null); store(HOST_KEY, h || "10.0.2.2"); }
      lastTokenSent = null; tick();
    },
    saveDeviceMapping: function (name, pkg) {
      var m = deviceMap();
      m[String(name || "").toLowerCase()] = pkg;
      store(MAP_KEY, JSON.stringify(m));
      tick();
    },
    syncNow: tick,
    getStatus: function () {
      var p = plugin();
      if (!p) return Promise.resolve({ isNative: false });
      return p.getStatus();
    },
    openSettings: function (kind) {
      var p = plugin();
      if (!p) return Promise.resolve();
      var methods = {
        accessibility: "openAccessibilitySettings",
        usage: "openUsageAccessSettings",
        battery: "openBatterySettings",
        admin: "openDeviceAdminSettings"
      };
      var fn = p[methods[kind] || "openAccessibilitySettings"];
      return fn ? fn.call(p) : Promise.resolve();
    },
    listInstalledApps: function () {
      var p = plugin();
      if (!p) return Promise.resolve({ apps: [] });
      return p.listInstalledApps();
    },
    onBlockedAttempt: function (cb) {
      var p = plugin();
      if (!p || !p.addListener) return Promise.resolve(null);
      return p.addListener("blockedAttempt", cb);
    }
  };

  setInterval(tick, 5000);
  setTimeout(tick, 3000);
})();
