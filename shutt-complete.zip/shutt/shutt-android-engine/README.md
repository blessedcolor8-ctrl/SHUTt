# Shutt Android blocking engine

Real, on-device app blocking for Shutt. When a locked app (e.g. WhatsApp) comes
to the foreground, an overlay covers it with a live countdown and the only ways
out are waiting it out, a paid/free emergency unlock, or returning to Shutt.

## How it works

```
web UI (Capacitor WebView) ──bridge──▶ ShuttEnforcerPlugin (Capacitor API)
                                            │ syncLocks / auth token / settings
                                            ▼
LockStore (SharedPreferences) ◀──poll── ShuttMonitorService (foreground svc)
        │ boils down to: packageName → unlockAt (works offline, UI closed)
        ▼
ShuttAccessibilityService ──TYPE_WINDOW_STATE_CHANGED──▶ foreground package?
        │ locked → BlockOverlay (TYPE_ACCESSIBILITY_OVERLAY, no permission needed)
        │ expired → sweep + "available again" notification
```

- **Enforcement = AccessibilityService.** This is the standard Android mechanism
  for app blockers. It sees foreground-app changes, needs no root, and its
  `TYPE_ACCESSIBILITY_OVERLAY` windows need no overlay permission and are not
  subject to background-activity-start restrictions.
- **Blocking works with the UI closed.** `ShuttMonitorService` (sticky
  foreground service) polls `GET /api/shutts/active` with the stored token and
  refreshes `LockStore`. The web UI also pushes lock updates on every change
  (fast path). Both write the same cache the service reads.
- **No backend changes.** The backend never learned Android package names, and
  it doesn't need to. Package resolution happens on-device:
  1. `PackageCatalog` maps the 32 catalog ids → known package names.
  2. `listInstalledApps()` scans what's *actually installed* (launcher intents —
     no `QUERY_ALL_PACKAGES` permission, no Play-policy headache).
  3. The "On this device" import tab lets users pick real installed apps; the
     web bridge remembers name → package in `localStorage` and passes packages
     in `syncLocks`. Custom/hand-added apps work the same way.
- **Emergency unlock is native too.** The overlay's unlock button calls
  `POST /api/shutts/:id/emergency-unlock` directly (same pricing rules as the
  server: free ≤ 1 week, $3 above), so it works even if the WebView is dead.

## Files

```
src/shutt-android/
  README.md                  this file
  plugin/                    local Capacitor plugin (shutt-enforcer-plugin)
    package.json
    src/index.ts             TS API + web fallback (every call no-ops off-device)
    android/build.gradle
    android/src/main/java/app/shutt/mobile/enforcer/
      ShuttEnforcerPlugin.kt      Capacitor bridge (auth, locks, status, intents)
      ShuttAccessibilityService.kt foreground detection + block trigger
      BlockOverlay.kt             full-screen countdown overlay + unlock
      LockStore.kt                SharedPreferences lock cache + auth
      PackageCatalog.kt           catalog id → package names + resolver
      ShuttApi.kt                 minimal HTTPS client (HttpURLConnection)
      ShuttMonitorService.kt      sticky foreground service, polls backend
      ShuttBootReceiver.kt        restarts monitor after reboot
      ShuttDeviceAdmin.kt         optional uninstall-resistance
    android/src/main/res/xml/
      accessibilityservice.xml
      device_admin.xml
  web/
    shutt-enforcer-bridge.js  include in the web bundle (preview-safe no-op)
    shutt-device-ui.js        floating setup + device-import sheet (separate
                              module, same React instance, zero bundle edits;
                              visible only on-device — pre-wired in web-app/)
    EnforcementBanner.jsx     setup-checklist banner (source path, optional —
                              device-ui.js already covers it prebuilt)
    DeviceImportSheet.jsx     device-import sheet (source path, optional)
    patches.md                source-path patches (JSX) if you prefer editing
                              shutt.jsx over the prebuilt device-ui.js
  AndroidManifest.snippet.xml copy-paste manifest block for the APK project
  backend/
    catalog-packages.json     reference map (already embedded natively)
  test/
    checklist.md              on-device test plan
```

## Build it in Android Studio (on your machine)

You need: Android Studio (SDK 34), Node 18+, and your backend reachable from
the phone (`npm run dev` in `backend/`, phone on the same Wi-Fi — use your
PC's LAN IP, e.g. `http://192.168.1.23:4000/api`).

```bash
# 1. from the Shutt project root (the unzipped archive)
cd mobile
npm install

# 2. install the enforcer plugin (copy this folder next to mobile/ first,
#    or reference wherever you put it)
npm install ../shutt-android/plugin
# (folder name must be shutt-enforcer-plugin — see plugin/package.json)

# 3. generate the native project (needs network — downloads the template)
npx cap add android

# 4. copy the web bundle + bridge, then sync
#    make sure web/shutt-enforcer-bridge.js is loaded by web-app/index.html
#    (see web/patches.md — one <script> tag + 4 one-line hooks)
npm run cap:sync        # build-www.js + cap sync android

# 5. merge the manifest (open in Android Studio, edit android/app/src/main/AndroidManifest.xml)
#    paste the <service>/<receiver>/<uses-permission> block from
#    "AndroidManifest snippet" below, and allow cleartext HTTP for local dev
#    (network_security_config.xml — same file mobile/README.md describes).

# 6. open + run
npx cap open android    # press Run, or Build > Build APK(s)
```

First launch on the phone: open Shutt → Apps → the red setup banner →
enable **Accessibility** (required), **Usage access** (for install detection),
and accept the **battery-optimization ignore** prompt (else Xiaomi/Oppo/OnePlus
will kill the monitor). Then lock WhatsApp for 1 minute, open WhatsApp, and
the Shutt overlay should cover it.

## AndroidManifest snippet

Inside `<manifest>` (permissions):

```xml
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" />
<uses-permission android:name="android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS" />
```

Inside `<application>`:

```xml
<service
    android:name="app.shutt.mobile.enforcer.ShuttAccessibilityService"
    android:exported="true"
    android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
    <intent-filter>
        <action android:name="android.accessibilityservice.AccessibilityService" />
    </intent-filter>
    <meta-data
        android:name="android.accessibilityservice"
        android:resource="@xml/accessibilityservice" />
</service>

<service
    android:name="app.shutt.mobile.enforcer.ShuttMonitorService"
    android:exported="false"
    android:foregroundServiceType="specialUse">
    <property
        android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
        android:value="Keeps Shutt app-blocking protection active by syncing lock state from your account." />
</service>

<receiver
    android:name="app.shutt.mobile.enforcer.ShuttBootReceiver"
    android:exported="true">
    <intent-filter>
        <action android:name="android.intent.action.BOOT_COMPLETED" />
        <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
    </intent-filter>
</receiver>

<receiver
    android:name="app.shutt.mobile.enforcer.ShuttDeviceAdmin"
    android:exported="false"
    android:permission="android.permission.BIND_DEVICE_ADMIN">
    <meta-data
        android:name="android.app.device_admin"
        android:resource="@xml/device_admin" />
    <intent-filter>
        <action android:name="android.app.action.DEVICE_ADMIN_ENABLED" />
    </intent-filter>
</receiver>
```

Copy `res/xml/accessibilityservice.xml` and `res/xml/device_admin.xml` from the
plugin into `android/app/src/main/res/xml/`.

## Honest limits (read before shipping)

- **AccessibilityService is user-revocable.** If the user turns it off, blocking
  stops. The banner + monitor notification make this visible; nothing on stock
  Android can force it (that's what MDM/parental-control certification is for).
- **OEM battery killers.** Xiaomi/MIUI, Oppo/ColorOS, Vivo, OnePlus aggressively
  kill background services. The plugin asks for battery-optimization ignore and
  the README checklist covers locking Shutt in recents; some devices still need
  "Autostart" enabled manually.
- **Play Store review.** Accessibility API usage requires a declaration +
  a video demo and a genuine need (a blocker qualifies, but review is manual).
  We deliberately avoid `QUERY_ALL_PACKAGES` (launcher-intent query instead) so
  that permission declaration isn't needed.
- **iOS cannot do this.** Family Controls is a different project entirely.
- **Uninstall dodge.** Device Admin (optional, off by default) refuses uninstall
  while active — but the user can deactivate it in Settings. True uninstall
  prevention needs device-owner provisioning (company/family devices).
