import type { PluginListenerHandle } from '@capacitor/core';
const { registerPlugin } = require('@capacitor/core');

export interface LockItem {
  appId: string;
  shuttId: string;
  packageName: string;
  label: string;
  unlockAt: number;
}

export interface InstalledApp {
  packageName: string;
  label: string;
}

export interface EnforcerStatus {
  isNative: boolean;
  accessibilityEnabled: boolean;
  usageAccessGranted: boolean;
  batteryExempt: boolean;
  monitorRunning: boolean;
  lockCount: number;
  blockedAttempts: number;
}

export interface ShuttEnforcerPlugin {
  /** Store auth so the native monitor can poll even with the UI closed. */
  setAuthToken(opts: { token: string; apiBase: string }): Promise<void>;
  clearAuth(): Promise<void>;
  /** Replace the native lock cache. Locks without a packageName are skipped. */
  syncLocks(opts: { locks: LockItem[] }): Promise<void>;
  getStatus(): Promise<EnforcerStatus>;
  /** Real installed (launchable) apps — no special permission needed. */
  listInstalledApps(): Promise<{ apps: InstalledApp[] }>;
  getBlockedAttempts(): Promise<{ attempts: { packageName: string; at: number }[] }>;
  openAccessibilitySettings(): Promise<void>;
  openUsageAccessSettings(): Promise<void>;
  openBatterySettings(): Promise<void>;
  openDeviceAdminSettings(): Promise<void>;
  addListener(
    event: 'blockedAttempt',
    cb: (info: { packageName: string; label: string; at: number }) => void,
  ): Promise<PluginListenerHandle>;
}

const fallback: ShuttEnforcerPlugin = {
  setAuthToken: async () => {},
  clearAuth: async () => {},
  syncLocks: async () => {},
  getStatus: async () => ({
    isNative: false,
    accessibilityEnabled: false,
    usageAccessGranted: false,
    batteryExempt: false,
    monitorRunning: false,
    lockCount: 0,
    blockedAttempts: 0,
  }),
  listInstalledApps: async () => ({ apps: [] }),
  getBlockedAttempts: async () => ({ attempts: [] }),
  openAccessibilitySettings: async () => {},
  openUsageAccessSettings: async () => {},
  openBatterySettings: async () => {},
  openDeviceAdminSettings: async () => {},
  addListener: async () => ({ remove: async () => {} } as unknown as PluginListenerHandle),
};

function load(): ShuttEnforcerPlugin {
  try {
    const w = window as any;
    if (w?.Capacitor?.isNativePlatform?.() && w?.Capacitor?.Plugins?.ShuttEnforcer) {
      return registerPlugin<ShuttEnforcerPlugin>('ShuttEnforcer');
    }
  } catch (e) { /* web fallback below */ }
  return fallback;
}

export const ShuttEnforcer: ShuttEnforcerPlugin = load();
