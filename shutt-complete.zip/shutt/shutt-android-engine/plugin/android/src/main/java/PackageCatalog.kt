package app.shutt.mobile.enforcer

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * Maps Shutt catalog ids (backend `APP_CATALOG`, mirrored in
 * `backend/catalog-packages.json`) to real Android package names, and resolves
 * which installed package a Shutt app entry means on *this* device.
 *
 * Resolution order for a catalog import:
 *  1. an installed package whose name is in the known list for that id;
 *  2. an installed package whose launcher label matches the app name
 *     (case-insensitive) — covers renames, regional variants, wrappers;
 *  3. null (app isn't installed → nothing to block; the web UI says so).
 *
 * Device imports (from [ShuttEnforcerPlugin.listInstalledApps]) carry the
 * exact packageName already, so they skip this map entirely.
 */
object PackageCatalog {

    /** catalog id → known package names (first = most common). */
    val KNOWN: Map<String, List<String>> = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "messenger" to listOf("com.facebook.orca"),
        "telegram" to listOf("org.telegram.messenger", "org.telegram.messenger.web"),
        "signal" to listOf("org.thoughtcrime.securesms"),
        "instagram" to listOf("com.instagram.android"),
        "facebook" to listOf("com.facebook.katana"),
        "x" to listOf("com.twitter.android"),
        "snapchat" to listOf("com.snapchat.android"),
        "reddit" to listOf("com.reddit.frontpage"),
        "linkedin" to listOf("com.linkedin.android"),
        "pinterest" to listOf("com.pinterest"),
        "tiktok" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        "youtube" to listOf("com.google.android.youtube"),
        "netflix" to listOf("com.netflix.mediaclient"),
        "disney-plus" to listOf("com.disney.disneyplus"),
        "twitch" to listOf("tv.twitch.android.app"),
        "spotify" to listOf("com.spotify.music"),
        "apple-music" to listOf("com.apple.android.music"),
        "soundcloud" to listOf("com.soundcloud.android"),
        "candy-crush" to listOf("com.king.candycrushsaga"),
        "clash-royale" to listOf("com.supercell.clashroyale"),
        "pubg-mobile" to listOf("com.tencent.ig"),
        "minecraft" to listOf("com.mojang.minecraftpe"),
        "gmail" to listOf("com.google.android.gm"),
        "slack" to listOf("com.Slack"),
        "notion" to listOf("notion.id"),
        "amazon" to listOf("com.amazon.mShop.android.shopping"),
        "ebay" to listOf("com.ebay.mobile"),
        "paypal" to listOf("com.paypal.android.p2pmobile"),
        "cash-app" to listOf("com.squareup.cash"),
        "google-maps" to listOf("com.google.android.apps.maps"),
        "uber" to listOf("com.ubercab")
    )

    data class InstalledApp(val packageName: String, val label: String)

    /**
     * Launchable apps on this device. Uses a MAIN/LAUNCHER intent query — no
     * QUERY_ALL_PACKAGES permission, no Play review flag.
     */
    fun listInstalled(ctx: Context): List<InstalledApp> {
        val pm: PackageManager = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<InstalledApp>()
        try {
            val infos = pm.queryIntentActivities(main, 0)
            for (info in infos) {
                val pkg = info.activityInfo?.packageName ?: continue
                if (pkg == ctx.packageName) continue // never list Shutt itself
                val label = try {
                    info.loadLabel(pm)?.toString() ?: pkg
                } catch (e: Exception) {
                    pkg
                }
                out.add(InstalledApp(pkg, label))
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return out.sortedBy { it.label.lowercase() }
    }

    /**
     * Resolve a catalog id + display name to an installed package, or null.
     * Pass a pre-fetched [installed] list when resolving in bulk.
     */
    fun resolve(
        ctx: Context,
        catalogId: String?,
        appName: String,
        installed: List<InstalledApp>? = null
    ): String? {
        val list = installed ?: listInstalled(ctx)
        if (list.isEmpty()) return null
        val byPkg = list.associateBy { it.packageName }
        if (catalogId != null) {
            for (candidate in KNOWN[catalogId].orEmpty()) {
                if (byPkg.containsKey(candidate)) return candidate
            }
        }
        val want = appName.trim().lowercase()
        // exact label match first, then startsWith (e.g. "WhatsApp Business")
        list.firstOrNull { it.label.lowercase() == want }?.let { return it.packageName }
        list.firstOrNull { it.label.lowercase().startsWith(want) }?.let { return it.packageName }
        return null
    }
}
