package app.shutt.mobile.enforcer

import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import org.json.JSONObject

/**
 * Capacitor bridge the web UI talks to (`window.Capacitor.Plugins.ShuttEnforcer`).
 * Every method is also safe to call when permissions are missing — callers get
 * status booleans and open the right settings screens instead of failing.
 */
@CapacitorPlugin(name = "ShuttEnforcer")
class ShuttEnforcerPlugin : Plugin() {

    private var blockedReceiver: BroadcastReceiver? = null

    override fun load() {
        val filter = IntentFilter(ShuttAccessibilityService.ACTION_BLOCKED)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action != ShuttAccessibilityService.ACTION_BLOCKED) return
                val data = JSObject().apply {
                    put("packageName", intent.getStringExtra("packageName") ?: "")
                    put("label", intent.getStringExtra("label") ?: "")
                    put("at", System.currentTimeMillis())
                }
                notifyListeners("blockedAttempt", data)
            }
        }
        blockedReceiver = receiver
        try {
            ContextCompat.registerReceiver(
                context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (e: Exception) {
            @Suppress("DEPRECATION")
            context.registerReceiver(receiver, filter)
        }
    }

    override fun handleOnDestroy() {
        try {
            blockedReceiver?.let { context.unregisterReceiver(it) }
        } catch (e: Exception) { /* ignore */ }
        blockedReceiver = null
        super.handleOnDestroy()
    }

    /** Store auth so the monitor can poll with the UI closed. Starts monitor. */
    @PluginMethod
    fun setAuthToken(call: PluginCall) {
        val token = call.getString("token")
        val apiBase = call.getString("apiBase")
        if (token.isNullOrBlank() || apiBase.isNullOrBlank()) {
            call.reject("token and apiBase are required")
            return
        }
        LockStore.saveAuth(context, token, apiBase)
        ShuttMonitorService.start(context)
        call.resolve()
    }

    @PluginMethod
    fun clearAuth(call: PluginCall) {
        LockStore.clearAuth(context)
        call.resolve()
    }

    /**
     * Replace the native lock cache. Items: {appId, shuttId, packageName,
     * label, unlockAt}. Items without a package are skipped (reported back).
     */
    @PluginMethod
    fun syncLocks(call: PluginCall) {
        val arr = call.getArray("locks") ?: JSArray()
        val locks = ArrayList<LockStore.Lock>()
        var skipped = 0
        for (i in 0 until arr.length()) {
            try {
                val o = arr.getJSONObject(i)
                val pkg = o.optString("packageName", "")
                if (pkg.isBlank()) {
                    skipped++
                    continue
                }
                locks.add(
                    LockStore.Lock(
                        appId = o.optString("appId"),
                        shuttId = o.optString("shuttId"),
                        packageName = pkg,
                        label = o.optString("label", pkg),
                        unlockAt = o.optLong("unlockAt", 0)
                    )
                )
            } catch (e: Exception) {
                skipped++
            }
        }
        LockStore.replaceLocks(context, locks)
        ShuttMonitorService.start(context)
        try {
            context.sendBroadcast(
                Intent(ShuttAccessibilityService.ACTION_LOCKS_CHANGED)
                    .setPackage(context.packageName)
            )
        } catch (e: Exception) { /* ignore */ }
        call.resolve(JSObject().apply { put("synced", locks.size); put("skipped", skipped) })
    }

    @PluginMethod
    fun getStatus(call: PluginCall) {
        call.resolve(
            JSObject().apply {
                put("isNative", true)
                put("accessibilityEnabled", ShuttAccessibilityService.isEnabled(context))
                put("usageAccessGranted", hasUsageAccess())
                put("batteryExempt", isBatteryExempt())
                put("deviceAdminActive", ShuttDeviceAdmin.isActive(context))
                put("monitorRunning", ShuttMonitorService.isRunning(context))
                put("lockCount", LockStore.lockCount(context))
                put("blockedAttempts", LockStore.blockedAttempts(context).size)
            }
        )
    }

    @PluginMethod
    fun listInstalledApps(call: PluginCall) {
        Thread {
            try {
                val apps = PackageCatalog.listInstalled(context)
                val arr = JSArray()
                for (a in apps) {
                    arr.put(
                        JSONObject().apply {
                            put("packageName", a.packageName)
                            put("label", a.label)
                        }
                    )
                }
                call.resolve(JSObject().apply { put("apps", arr) })
            } catch (e: Exception) {
                call.reject("Could not list apps: ${e.message}")
            }
        }.start()
    }

    @PluginMethod
    fun getBlockedAttempts(call: PluginCall) {
        val arr = JSArray()
        for (a in LockStore.blockedAttempts(context)) {
            arr.put(JSONObject().apply {
                put("packageName", a.packageName)
                put("at", a.at)
            })
        }
        call.resolve(JSObject().apply { put("attempts", arr) })
    }

    // ---------- settings intents (all best-effort, never throw) ----------

    @PluginMethod
    fun openAccessibilitySettings(call: PluginCall) {
        openSettings(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS), call)
    }

    @PluginMethod
    fun openUsageAccessSettings(call: PluginCall) {
        openSettings(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS), call)
    }

    @PluginMethod
    fun openBatterySettings(call: PluginCall) {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            openSettings(intent, call)
        } catch (e: Exception) {
            openSettings(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), call)
        }
    }

    @PluginMethod
    fun openDeviceAdminSettings(call: PluginCall) {
        try {
            val comp = ComponentName(context, ShuttDeviceAdmin::class.java)
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
                putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Lets Shutt refuse uninstall while protection is on, so locked apps stay blocked."
                )
            }
            openSettings(intent, call)
        } catch (e: Exception) {
            call.reject("Device admin is not available on this device")
        }
    }

    // ---------- helpers ----------

    private fun openSettings(intent: Intent, call: PluginCall) {
        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            call.resolve()
        } catch (e: Exception) {
            call.reject("Could not open settings: ${e.message}")
        }
    }

    private fun hasUsageAccess(): Boolean {
        return try {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
                )
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    private fun isBatteryExempt(): Boolean {
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            pm.isIgnoringBatteryOptimizations(context.packageName)
        } catch (e: Exception) {
            false
        }
    }
}
