package app.shutt.mobile.enforcer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder

/**
 * Sticky foreground service: keeps the native lock cache fresh even when the
 * Shutt UI is closed, killed, or hasn't run since boot. Polls
 * GET /api/shutts/active (+ /api/apps for names) every [POLL_MS] and merges
 * the result into [LockStore], preserving package mappings the web UI synced
 * earlier (the server only knows app ids, never package names).
 *
 * Foreground + sticky + boot receiver is the most a stock-Android app can do
 * to stay alive; OEM battery optimizers can still kill it (see README — the
 * plugin asks for battery-optimization ignore).
 */
class ShuttMonitorService : Service() {

    companion object {
        const val CHANNEL_ID = "shutt_protection"
        const val NOTIF_ID = 41
        private const val POLL_MS = 30_000L

        fun start(ctx: Context) {
            try {
                val intent = Intent(ctx.applicationContext, ShuttMonitorService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    ctx.applicationContext.startForegroundService(intent)
                } else {
                    ctx.applicationContext.startService(intent)
                }
            } catch (e: Exception) { /* service unavailable; enforcement still works from cache */ }
        }

        fun isRunning(ctx: Context): Boolean {
            return try {
                val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                @Suppress("DEPRECATION")
                am.getRunningServices(Int.MAX_VALUE).any {
                    it.service.className == ShuttMonitorService::class.java.name
                }
            } catch (e: Exception) {
                false
            }
        }
    }

    private var worker: HandlerThread? = null
    private var handler: Handler? = null

    private val poller = object : Runnable {
        override fun run() {
            try {
                pollOnce()
            } catch (e: Exception) { /* never die on poll errors */ }
            handler?.postDelayed(this, POLL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannel()
        startForegroundPinned()
        val t = HandlerThread("shutt-monitor").also { it.start() }
        worker = t
        handler = Handler(t.looper).also { it.post(poller) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundPinned()
        return START_STICKY
    }

    override fun onDestroy() {
        handler?.removeCallbacks(poller)
        worker?.quitSafely()
        super.onDestroy()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID,
                        "Shutt protection",
                        NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        description = "Keeps Shutt app blocking active."
                    }
                )
            }
        } catch (e: Exception) { /* ignore */ }
    }

    private fun startForegroundPinned() {
        try {
            val notif = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("Shutt protection is on")
                    .setContentText("Locked apps stay blocked.")
                    .setSmallIcon(android.R.drawable.ic_lock_lock)
                    .setOngoing(true)
                    .build()
            } else {
                @Suppress("DEPRECATION")
                Notification.Builder(this)
                    .setContentTitle("Shutt protection is on")
                    .setContentText("Locked apps stay blocked.")
                    .setSmallIcon(android.R.drawable.ic_lock_lock)
                    .setOngoing(true)
                    .build()
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIF_ID, notif,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                @Suppress("DEPRECATION")
                startForeground(NOTIF_ID, notif)
            }
        } catch (e: Exception) { /* foreground failed; stay alive as background service */ }
    }

    /**
     * One poll: active shutts + app names → merge into LockStore. Package
     * mapping comes from the previously synced cache (appId → packageName);
     * anything unmapped is left for the next web-UI sync (documented limit).
     */
    private fun pollOnce() {
        val token = LockStore.getToken(this) ?: return
        val api = LockStore.getApiBase(this) ?: return
        val active = ShuttApi.getActiveShutts(api, token) ?: return // offline: keep cache
        val apps = ShuttApi.getApps(api, token) ?: emptyList()
        val nameOf = apps.associate { it.id to it.name }

        // previous mapping appId → (package, label)
        val prev = LockStore.activeLocks(this).associateBy { it.appId }
        val merged = ArrayList<LockStore.Lock>()
        for (s in active) {
            val old = prev[s.appId]
            // also accept names the web bridge resolved before
            val pkg = old?.packageName
                ?: PackageCatalog.resolve(this, null, nameOf[s.appId] ?: continue)
                ?: continue // unknown package — wait for a web-UI sync
            val label = old?.label ?: (nameOf[s.appId] ?: s.appId)
            merged.add(LockStore.Lock(s.appId, s.id, pkg, label, s.unlockAt))
        }
        // tell the accessibility service in case an overlay went stale
        // (a lock ended/unlocked from elsewhere while its overlay is up)
        val before = prev.values.map { it.shuttId }.toSet()
        val after = merged.map { it.shuttId }.toSet()
        LockStore.replaceLocks(this, merged)
        if (before.any { it !in after }) {
            sendBroadcast(Intent(ShuttAccessibilityService.ACTION_LOCKS_CHANGED).setPackage(packageName))
        }
    }
}
