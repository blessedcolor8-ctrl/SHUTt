package app.shutt.mobile.enforcer

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Minimal Shutt backend client over HttpURLConnection — no OkHttp/Rertofit
 * dependency, so the plugin stays dependency-free. Runs on background threads
 * only (callers own threading). Timeouts are short: enforcement must never
 * hang waiting on network.
 */
object ShuttApi {

    data class ActiveShutt(
        val id: String,
        val appId: String,
        val unlockAt: Long
    )

    data class ActiveApp(
        val id: String,
        val name: String,
        val unlockAt: Long?,
        val shuttId: String?
    )

    data class EmergencyResult(val ok: Boolean, val charge: Double, val error: String?)

    private const val CONNECT_TIMEOUT = 8000
    private const val READ_TIMEOUT = 8000

    private fun open(path: String, apiBase: String, token: String?, method: String): HttpURLConnection {
        val conn = URL(apiBase.trimEnd('/') + path).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = CONNECT_TIMEOUT
        conn.readTimeout = READ_TIMEOUT
        conn.setRequestProperty("Content-Type", "application/json")
        if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
        return conn
    }

    private fun readBody(conn: HttpURLConnection): String {
        val stream = try {
            if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        } catch (e: Exception) {
            null
        } ?: return ""
        return try {
            BufferedReader(InputStreamReader(stream)).use { it.readText() }
        } catch (e: Exception) {
            ""
        }
    }

    /** GET /api/shutts/active — the monitor's poll. Null on any failure. */
    fun getActiveShutts(apiBase: String, token: String): List<ActiveShutt>? {
        return try {
            val conn = open("/shutts/active", apiBase, token, "GET")
            val code = conn.responseCode
            if (code !in 200..299) return null
            val arr = JSONArray(readBody(conn))
            ArrayList<ActiveShutt>().also { out ->
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    out.add(
                        ActiveShutt(
                            id = o.optString("id"),
                            appId = o.optString("app_id"),
                            unlockAt = o.optLong("unlock_at")
                        )
                    )
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    /** GET /api/apps — names + lock status, so the monitor can label locks. */
    fun getApps(apiBase: String, token: String): List<ActiveApp>? {
        return try {
            val conn = open("/apps", apiBase, token, "GET")
            if (conn.responseCode !in 200..299) return null
            val arr = JSONArray(readBody(conn))
            ArrayList<ActiveApp>().also { out ->
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    out.add(
                        ActiveApp(
                            id = o.optString("id"),
                            name = o.optString("name"),
                            unlockAt = if (o.isNull("unlockAt")) null else o.optLong("unlockAt"),
                            shuttId = if (o.isNull("shuttId")) null else o.optString("shuttId")
                        )
                    )
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    /** POST /api/shutts/:id/emergency-unlock — the overlay's unlock button. */
    fun emergencyUnlock(apiBase: String, token: String, shuttId: String): EmergencyResult {
        return try {
            val conn = open("/shutts/$shuttId/emergency-unlock", apiBase, token, "POST")
            conn.doOutput = true
            try {
                OutputStreamWriter(conn.outputStream).use { it.write("{}") }
            } catch (e: Exception) { /* some servers dislike empty bodies; ignore */ }
            val code = conn.responseCode
            val body = readBody(conn)
            if (code !in 200..299) {
                val msg = try {
                    JSONObject(body).optString("error", "Unlock failed ($code)")
                } catch (e: Exception) {
                    "Unlock failed ($code)"
                }
                return EmergencyResult(false, 0.0, msg)
            }
            val charge = try {
                JSONObject(body).getJSONObject("shutt").optDouble("emergencyCharge", 0.0)
            } catch (e: Exception) {
                0.0
            }
            EmergencyResult(true, charge, null)
        } catch (e: Exception) {
            EmergencyResult(false, 0.0, e.message ?: "Network error")
        }
    }
}
