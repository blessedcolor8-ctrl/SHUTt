package app.shutt.mobile.enforcer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Restarts the monitor after reboot / app update so the lock cache keeps
 * syncing. (The OS restarts enabled accessibility services on its own;
 * this covers the polling side.)
 */
class ShuttBootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            // only worth running if the user ever signed in on this device
            if (LockStore.getToken(ctx) != null) {
                ShuttMonitorService.start(ctx)
            }
        }
    }
}
