package app.shutt.mobile.enforcer

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat

/**
 * The actual blocking engine. Watches foreground-app changes; when a package
 * with an active lock comes forward, [BlockOverlay] covers it with a live
 * countdown. The only exits are: wait it out, emergency unlock (same server
 * rules as the app), or jump back into Shutt.
 *
 * Reads [LockStore] (local cache) — never network — so blocks are instant and
 * work offline / with the UI closed / after reboot (the OS restarts enabled
 * accessibility services automatically).
 */
class ShuttAccessibilityService : AccessibilityService() {

    companion object {
        const val ACTION_HIDE_OVERLAY = "app.shutt.mobile.enforcer.HIDE_OVERLAY"
        const val ACTION_LOCKS_CHANGED = "app.shutt.mobile.enforcer.LOCKS_CHANGED"
        const val ACTION_BLOCKED = "app.shutt.mobile.enforcer.BLOCKED"

        /** True if the user has enabled *this* service. */
        fun isEnabled(ctx: Context): Boolean {
            return try {
                val expected = android.content.ComponentName(ctx, ShuttAccessibilityService::class.java)
                    .flattenToString()
                val enabled = android.provider.Settings.Secure.getString(
                    ctx.contentResolver,
                    android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ) ?: return false
                enabled.split(':').any { it.equals(expected, ignoreCase = true) }
            } catch (e: Exception) {
                false
            }
        }
    }

    private var overlay: BlockOverlay? = null
    private var shownForShuttId: String? = null

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_HIDE_OVERLAY -> hideOverlay()
                ACTION_LOCKS_CHANGED -> {
                    // a lock may have been lifted while its overlay is up
                    val shown = shownForShuttId
                    if (shown != null &&
                        LockStore.activeLocks(this@ShuttAccessibilityService)
                            .none { it.shuttId == shown }
                    ) {
                        hideOverlay()
                    }
                }
            }
        }
    }

    override fun onServiceConnected() {
        val filter = IntentFilter().apply {
            addAction(ACTION_HIDE_OVERLAY)
            addAction(ACTION_LOCKS_CHANGED)
        }
        try {
            ContextCompat.registerReceiver(
                this, commandReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (e: Exception) {
            @Suppress("DEPRECATION")
            registerReceiver(commandReceiver, filter)
        }
        // make sure the monitor is running whenever enforcement is on
        ShuttMonitorService.start(this)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        hideOverlay()
        try {
            unregisterReceiver(commandReceiver)
        } catch (e: Exception) { /* already gone */ }
        return false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val type = event.eventType
        if (type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) return

        val pkg = event.packageName?.toString() ?: return
        // never block ourselves, the installer, or the system UI
        if (pkg == packageName) {
            // returning to Shutt dismisses any stale overlay
            if (shownForShuttId != null) hideOverlay()
            return
        }
        if (pkg == "com.android.systemui") return

        val lock = LockStore.lockForPackage(this, pkg) ?: run {
            // foreground app isn't locked — dismiss overlay only if it was
            // showing for an app that is no longer in front AND unlocked.
            // (Keep it simple: leave overlay state to explicit hide events.)
            return
        }

        // already showing for this exact lock → just refresh the countdown
        if (shownForShuttId == lock.shuttId) {
            overlay?.update(lock)
            return
        }

        showOverlay(lock)
    }

    override fun onInterrupt() {
        hideOverlay()
    }

    private fun showOverlay(lock: LockStore.Lock) {
        try {
            hideOverlay()
            val ov = BlockOverlay(
                this,
                onEmergencyUnlock = { unlockShutt(lock) },
                onOpenShutt = { openShuttApp() }
            )
            ov.show(lock)
            overlay = ov
            shownForShuttId = lock.shuttId
            LockStore.recordBlockedAttempt(this, lock.packageName)
            sendBroadcast(Intent(ACTION_BLOCKED).apply {
                setPackage(packageName)
                putExtra("packageName", lock.packageName)
                putExtra("label", lock.label)
            })
        } catch (e: Exception) {
            // overlay failed (shouldn't happen) — never crash the service
            hideOverlay()
        }
    }

    private fun hideOverlay() {
        shownForShuttId = null
        try {
            overlay?.hide()
        } catch (e: Exception) { /* ignore */ }
        overlay = null
    }

    /** Overlay button → server emergency unlock on a worker thread. */
    private fun unlockShutt(lock: LockStore.Lock) {
        val ov = overlay ?: return
        ov.setBusy(true)
        Thread {
            try {
                val token = LockStore.getToken(this)
                val api = LockStore.getApiBase(this)
                if (token.isNullOrBlank() || api.isNullOrBlank()) {
                    ov.showError("Not signed in on this device — open Shutt and log in.")
                    ov.setBusy(false)
                    return@Thread
                }
                val res = ShuttApi.emergencyUnlock(api, token, lock.shuttId)
                // back to the main thread for UI
                android.os.Handler(mainLooper).post {
                    if (res.ok) {
                        LockStore.removeLock(this, lock.shuttId)
                        sendBroadcast(Intent(ACTION_LOCKS_CHANGED).setPackage(packageName))
                        hideOverlay()
                        android.widget.Toast.makeText(
                            this,
                            if (res.charge > 0) "Unlocked early — $${res.charge} charged"
                            else "Unlocked early — free, no charge",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    } else {
                        ov.showError(res.error ?: "Unlock failed")
                        ov.setBusy(false)
                    }
                }
            } catch (e: Exception) {
                android.os.Handler(mainLooper).post {
                    ov.showError(e.message ?: "Network error")
                    ov.setBusy(false)
                }
            }
        }.start()
    }

    /** Overlay button → bring Shutt to the front. */
    private fun openShuttApp() {
        try {
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(launch)
            }
        } catch (e: Exception) { /* ignore */ }
    }

    @Suppress("unused")
    private fun currentApi(): Int = Build.VERSION.SDK_INT
}
