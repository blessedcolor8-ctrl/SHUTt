package app.shutt.mobile.enforcer

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * The single source of truth the [ShuttAccessibilityService] reads on every
 * foreground-app change. Plain SharedPreferences (private mode) so enforcement
 * works with the UI closed, offline, and right after boot — no WebView, no
 * network on the hot path. Every read sweeps expired locks in memory.
 *
 * NOTE: the auth token lives here in plain text. Fine for a personal build;
 * switch to EncryptedSharedPreferences (androidx.security:security-crypto)
 * before any public release.
 */
object LockStore {
    private const val PREFS = "shutt_enforcer"
    private const val KEY_LOCKS = "locks_v1"
    private const val KEY_TOKEN = "auth_token"
    private const val KEY_API = "api_base"
    private const val KEY_ATTEMPTS = "blocked_attempts_v1"

    data class Lock(
        val appId: String,
        val shuttId: String,
        val packageName: String,
        val label: String,
        val unlockAt: Long
    )

    data class BlockAttempt(val packageName: String, val at: Long)

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun saveAuth(ctx: Context, token: String, apiBase: String) {
        prefs(ctx).edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_API, apiBase.trimEnd('/'))
            .apply()
    }

    fun clearAuth(ctx: Context) {
        prefs(ctx).edit().remove(KEY_TOKEN).apply()
    }

    fun getToken(ctx: Context): String? = prefs(ctx).getString(KEY_TOKEN, null)
    fun getApiBase(ctx: Context): String? = prefs(ctx).getString(KEY_API, null)

    /** Replace the whole cache (web UI pushes the full locked set). */
    fun replaceLocks(ctx: Context, locks: List<Lock>) {
        val arr = JSONArray()
        val now = System.currentTimeMillis()
        for (l in locks) {
            if (l.packageName.isBlank()) continue
            if (l.unlockAt <= now) continue // already expired, don't cache
            arr.put(
                JSONObject()
                    .put("appId", l.appId)
                    .put("shuttId", l.shuttId)
                    .put("packageName", l.packageName)
                    .put("label", l.label)
                    .put("unlockAt", l.unlockAt)
            )
        }
        prefs(ctx).edit().putString(KEY_LOCKS, arr.toString()).apply()
    }

    fun removeLock(ctx: Context, shuttId: String) {
        val kept = loadRaw(ctx).filter { it.shuttId != shuttId }
        persist(ctx, kept)
    }

    private fun loadRaw(ctx: Context): List<Lock> {
        val raw = prefs(ctx).getString(KEY_LOCKS, null) ?: return emptyList()
        val out = ArrayList<Lock>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Lock(
                        appId = o.optString("appId"),
                        shuttId = o.optString("shuttId"),
                        packageName = o.optString("packageName"),
                        label = o.optString("label"),
                        unlockAt = o.optLong("unlockAt")
                    )
                )
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return out
    }

    private fun persist(ctx: Context, locks: List<Lock>) {
        val arr = JSONArray()
        for (l in locks) {
            arr.put(
                JSONObject()
                    .put("appId", l.appId)
                    .put("shuttId", l.shuttId)
                    .put("packageName", l.packageName)
                    .put("label", l.label)
                    .put("unlockAt", l.unlockAt)
            )
        }
        prefs(ctx).edit().putString(KEY_LOCKS, arr.toString()).apply()
    }

    /**
     * Active (unexpired) locks. Expired ones are dropped from the cache and
     * reported back so callers can notify ("available again").
     */
    fun activeLocks(ctx: Context): List<Lock> {
        val now = System.currentTimeMillis()
        val all = loadRaw(ctx)
        val active = all.filter { it.unlockAt > now }
        if (active.size != all.size) persist(ctx, active)
        return active
    }

    fun lockForPackage(ctx: Context, packageName: String): Lock? {
        val now = System.currentTimeMillis()
        return activeLocks(ctx).firstOrNull {
            it.packageName == packageName && it.unlockAt > now
        }
    }

    fun lockCount(ctx: Context): Int = activeLocks(ctx).size

    fun recordBlockedAttempt(ctx: Context, packageName: String) {
        val p = prefs(ctx)
        val attempts = blockedAttempts(ctx).toMutableList()
        attempts.add(BlockAttempt(packageName, System.currentTimeMillis()))
        // keep the last 200
        val trimmed = attempts.takeLast(200)
        val arr = JSONArray()
        for (a in trimmed) {
            arr.put(JSONObject().put("packageName", a.packageName).put("at", a.at))
        }
        p.edit().putString(KEY_ATTEMPTS, arr.toString()).apply()
    }

    fun blockedAttempts(ctx: Context): List<BlockAttempt> {
        val raw = prefs(ctx).getString(KEY_ATTEMPTS, null) ?: return emptyList()
        val out = ArrayList<BlockAttempt>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(BlockAttempt(o.optString("packageName"), o.optLong("at")))
            }
        } catch (e: Exception) {
            return emptyList()
        }
        return out
    }
}
