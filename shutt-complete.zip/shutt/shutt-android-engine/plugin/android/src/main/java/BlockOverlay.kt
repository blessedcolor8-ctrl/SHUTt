package app.shutt.mobile.enforcer

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Full-screen block screen shown over a locked app. Built programmatically
 * (no layout XML to merge) and attached as TYPE_ACCESSIBILITY_OVERLAY, which
 * an AccessibilityService may add without any extra permission and which the
 * background-activity-start restrictions don't apply to.
 *
 * Content: app label, "Locked" pill, live D/H/M/S countdown, started/unlocks
 * rows, emergency-unlock button (free or $3 note comes from the server rules),
 * and an "Open Shutt" button. Touches are fully consumed — the app underneath
 * can't be used while this is up.
 */
class BlockOverlay(
    private val ctx: Context,
    private val onEmergencyUnlock: () -> Unit,
    private val onOpenShutt: () -> Unit
) {
    private val wm: WindowManager =
        ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var root: View? = null
    private var dayView: TextView? = null
    private var hourView: TextView? = null
    private var minView: TextView? = null
    private var secView: TextView? = null
    private var unlockBtn: Button? = null
    private var errorView: TextView? = null
    private var busy = false

    private var lock: LockStore.Lock? = null
    private var attached = false

    private val ticker = object : Runnable {
        override fun run() {
            val l = lock ?: return
            val remaining = l.unlockAt - System.currentTimeMillis()
            if (remaining <= 0) {
                hide()
                return
            }
            render(remaining)
            handler.postDelayed(this, 1000)
        }
    }

    fun show(lock: LockStore.Lock) {
        this.lock = lock
        if (!attached) attach()
        render(lock.unlockAt - System.currentTimeMillis())
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    fun update(lock: LockStore.Lock) {
        this.lock = lock
        if (attached) render(lock.unlockAt - System.currentTimeMillis())
    }

    fun setBusy(b: Boolean) {
        busy = b
        unlockBtn?.isEnabled = !b
        unlockBtn?.text = if (b) "Working…" else "Emergency unlock — Free"
    }

    fun showError(msg: String) {
        errorView?.let {
            it.text = msg
            it.visibility = View.VISIBLE
        }
    }

    fun hide() {
        handler.removeCallbacks(ticker)
        if (!attached) return
        try {
            root?.let { wm.removeView(it) }
        } catch (e: Exception) { /* already removed */ }
        attached = false
        root = null
    }

    // ---------- view construction ----------

    private fun attach() {
        val l = lock ?: return
        val density = ctx.resources.displayMetrics.density
        fun dp(n: Int): Int = (n * density + 0.5f).toInt()

        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.WHITE)
            setPadding(dp(28), dp(64), dp(28), dp(40))
        }

        val title = TextView(ctx).apply {
            text = "Shutt"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#141414"))
            gravity = Gravity.CENTER
        }
        col.addView(title)

        val appName = TextView(ctx).apply {
            text = l.label
            textSize = 30f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#141414"))
            gravity = Gravity.CENTER
        }
        col.addView(appName, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })

        val pill = TextView(ctx).apply {
            text = "⬒ Locked"
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#E01B22"))
            setPadding(dp(18), dp(8), dp(18), dp(8))
            gravity = Gravity.CENTER
        }
        col.addView(pill, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12); gravity = Gravity.CENTER_HORIZONTAL })

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        dayView = countdownCell(row, "DAYS", dp)
        hourView = countdownCell(row, "HRS", dp)
        minView = countdownCell(row, "MIN", dp)
        secView = countdownCell(row, "SEC", dp)
        col.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(26) })

        val note = TextView(ctx).apply {
            text = "Shutt can't be paused — an emergency unlock is the only early way out. Free for shutts of a week or under; $3 beyond that."
            textSize = 13f
            setTextColor(Color.parseColor("#75726F"))
            gravity = Gravity.CENTER
        }
        col.addView(note, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(22) })

        errorView = TextView(ctx).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#D64545"))
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        col.addView(errorView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) })

        val unlock = Button(ctx).apply {
            text = "Emergency unlock — Free"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#E01B22"))
            isAllCaps = false
            setOnClickListener { if (!busy) onEmergencyUnlock() }
        }
        unlockBtn = unlock
        col.addView(unlock, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(54)
        ).apply { topMargin = dp(18) })

        val open = Button(ctx).apply {
            text = "Open Shutt"
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.parseColor("#0B6B3A"))
            setBackgroundColor(Color.parseColor("#E6F5EC"))
            isAllCaps = false
            setOnClickListener { onOpenShutt() }
        }
        col.addView(open, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(54)
        ).apply { topMargin = dp(10) })

        val scroll = android.widget.ScrollView(ctx).apply { addView(col) }

        // TYPE_ACCESSIBILITY_OVERLAY needs no permission (API 26+; minSdk is 26).
        @Suppress("DEPRECATION")
        val type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(scroll, params)
            root = scroll
            attached = true
        } catch (e: Exception) {
            attached = false
        }
    }

    private fun countdownCell(parent: LinearLayout, label: String, dp: (Int) -> Int): TextView {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#141414"))
            setPadding(dp(4), dp(14), dp(4), dp(10))
        }
        val num = TextView(ctx).apply {
            text = "0"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            minWidth = dp(64)
        }
        val lab = TextView(ctx).apply {
            text = label
            textSize = 10f
            setTextColor(Color.parseColor("#A9A6A2"))
            gravity = Gravity.CENTER
        }
        box.addView(num)
        box.addView(lab)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(4); lp.marginEnd = dp(4)
        parent.addView(box, lp)
        return num
    }

    private fun render(remainingMs: Long) {
        val days = TimeUnit.MILLISECONDS.toDays(remainingMs)
        val hours = TimeUnit.MILLISECONDS.toHours(remainingMs) % 24
        val mins = TimeUnit.MILLISECONDS.toMinutes(remainingMs) % 60
        val secs = TimeUnit.MILLISECONDS.toSeconds(remainingMs) % 60
        dayView?.text = days.toString()
        hourView?.text = String.format(Locale.US, "%02d", hours)
        minView?.text = String.format(Locale.US, "%02d", mins)
        secView?.text = String.format(Locale.US, "%02d", secs)
    }

    @Suppress("unused")
    private fun apiLevel(): Int = Build.VERSION.SDK_INT
}
