package app.shutt.mobile.enforcer

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/**
 * OPTIONAL uninstall-resistance. While this admin is active, Android refuses
 * to uninstall Shutt — closing the easiest dodge (delete the blocker).
 * The user can still deactivate it in Settings → Security → Device admin
 * apps, so this raises the bar rather than removing the dodge; true
 * uninstall prevention needs device-owner provisioning (family/company
 * devices). Off by default; the web banner offers it as "Extra: prevent
 * uninstall" and the plugin opens the activation screen.
 */
class ShuttDeviceAdmin : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
    }

    companion object {
        fun isActive(ctx: Context): Boolean {
            return try {
                val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE)
                    as android.app.admin.DevicePolicyManager
                val comp = android.content.ComponentName(ctx, ShuttDeviceAdmin::class.java)
                dpm.isAdminActive(comp)
            } catch (e: Exception) {
                false
            }
        }
    }
}
