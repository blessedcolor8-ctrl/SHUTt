# On-device test plan (phone + Android Studio)

Setup: backend running on your PC (`cd backend && npm run dev`), phone on the
same Wi-Fi, debug APK installed (`adb install app-debug.apk`), logcat open
(`adb logcat | grep -i shutt`).

## 1. Permissions ladder
- [ ] Fresh install → log in → Apps tab shows the **red "Protection is off"**
      banner (not visible in any browser — native only).
- [ ] "Accessibility" → system screen → enable Shutt → back: banner step
      turns green, `getStatus.accessibilityEnabled == true`.
- [ ] "Usage access" → allow → green. "Battery: don't optimize" → allow.
- [ ] Xiaomi/Oppo/OnePlus: also enable Autostart + lock Shutt in recents
      (phone-specific, no API for it).

## 2. First real block (catalog app)
- [ ] Import WhatsApp **from the catalog** (must be installed on the phone).
- [ ] Lock it for **1 minute**. Within ~5s the monitor/WebView syncs.
- [ ] Open WhatsApp → Shutt overlay covers it instantly: label, Locked pill,
      countdown ticking 00:00:5x:xx.
- [ ] Press Home/Back: overlay stays (touches consumed), WhatsApp unusable.
- [ ] "Open Shutt" → returns to Shutt, overlay dismisses.
- [ ] Wait out the minute → overlay auto-dismisses on next tick; backend
      notification "WhatsApp is available again" appears in Shutt's bell.

## 3. Device import + custom app
- [ ] "On this device (real blocking)" lists real installed apps with package
      names. Import one → lock it → it blocks.
- [ ] Add-by-hand an installed app's exact label → lock → blocks (label match).

## 4. Emergency unlock from the overlay (WebView dead)
- [ ] Force-stop Shutt from recents (leave accessibility on).
- [ ] Lock an app from another logged-in client (or relock before killing).
- [ ] Open the locked app → overlay → "Emergency unlock" → server charge
      applies (free ≤ 1 week) → overlay dismisses, app opens.
- [ ] `adb logcat`: no exceptions from the service.

## 5. Survival
- [ ] Reboot → without opening Shutt, open a still-locked app → blocked
      (a11y auto-restarts; monitor restarts via BOOT_COMPLETED and re-syncs).
- [ ] Airplane mode → existing locks still block (local cache); unlock
      button shows the offline error honestly.
- [ ] Battery: 8h idle → monitor notification persistent, locks intact.

## 6. Premium path
- [ ] Free user locks 2 weeks → 402 → upgrade → lock succeeds → emergency
      unlock from overlay charges $3 (check billing history in Settings).

## 7. Dodge attempts (document, don't fix the unfixable)
- [ ] Force-stop Shutt → a11y service restarts (system), monitor restarts
      (sticky); blocking resumes.
- [ ] Disable accessibility → blocking stops; banner goes red on next open.
- [ ] Uninstall with device admin active → refused; after deactivating admin
      → uninstall succeeds (expected; true prevention needs device-owner).
