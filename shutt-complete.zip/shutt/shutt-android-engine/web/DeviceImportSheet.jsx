// DeviceImportSheet.jsx — "On this device" import tab.
// Lists apps ACTUALLY INSTALLED on the phone (via the native plugin) so a
// lock maps to a real package. Falls back to a closed message in the browser.
// Paste into shutt.jsx below ImportAppsSheet, then wire per patches.md P4.
//
// Props: { deviceApps, existingNames, onClose, onImportDevice(entries, close),
//          busy }
//   deviceApps: [{packageName, label}] from ShuttEnforcerBridge.listInstalledApps()
//   onImportDevice: (entries:[{name, packageName}], closeSheet) => Promise

function DeviceImportSheet({ deviceApps, existingNames, onClose, onImportDevice, busy }) {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(() => ({}));
  const existing = new Set(existingNames.map((n) => n.toLowerCase()));
  const q = query.trim().toLowerCase();
  const list = (deviceApps || [])
    .filter((d) => !existing.has(d.label.toLowerCase()))
    .filter((d) => !q || d.label.toLowerCase().includes(q));

  const toggle = (pkg) => setSelected((prev) => {
    const next = { ...prev };
    if (next[pkg]) delete next[pkg];
    else {
      const found = (deviceApps || []).find((d) => d.packageName === pkg);
      if (found) next[pkg] = found;
    }
    return next;
  });

  const entries = Object.values(selected);
  const B = window.ShuttEnforcerBridge;
  const isNative = !!(B && B.isNative());

  return (
    <div style={{ position: "absolute", inset: 0, zIndex: 40, display: "flex", flexDirection: "column", justifyContent: "flex-end" }}>
      <div onClick={onClose} style={{ position: "absolute", inset: 0, background: "rgba(20,20,20,0.55)" }} />
      <div style={{ position: "relative", background: C.paper, borderRadius: "26px 26px 0 0", padding: "10px 22px 20px", maxHeight: "88%", display: "flex", flexDirection: "column" }}>
        <div style={{ width: 40, height: 4, borderRadius: 2, background: C.line, margin: "6px auto 16px", flexShrink: 0 }} />

        <div style={{ display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 17, color: C.ink }}>On this device</div>
            <div style={{ fontFamily: FONT, fontWeight: 500, fontSize: 12.5, color: C.steel }}>
              {isNative ? "Real installed apps — locks block these for real" : "Available in the Android app"}
            </div>
          </div>
          <button onClick={onClose} style={{ background: C.off, border: "none", borderRadius: 10, width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0 }}>
            <X size={17} color={C.ink} strokeWidth={2.6} />
          </button>
        </div>

        <div style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 10, background: C.off, border: `1px solid ${C.line}`, borderRadius: 14, padding: "0 14px", flexShrink: 0 }}>
          <Search size={16} color={C.steel} strokeWidth={2.4} />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search installed apps" style={{ flex: 1, height: 42, border: "none", background: "none", outline: "none", fontFamily: FONT, fontSize: 14, fontWeight: 500, color: C.ink }} />
        </div>

        <div style={{ overflowY: "auto", flex: 1, marginTop: 8 }}>
          {!isNative && (
            <div style={{ padding: "24px 4px", textAlign: "center", fontFamily: FONT, fontWeight: 500, fontSize: 13, color: C.steel }}>
              Install the Android app to pick from your real installed apps. In the browser, use the catalog instead.
            </div>
          )}
          {isNative && list.length === 0 && (
            <div style={{ padding: "24px 4px", textAlign: "center", fontFamily: FONT, fontWeight: 500, fontSize: 13, color: C.steel }}>
              No matching installed apps.
            </div>
          )}
          {isNative && list.map((d, i) => {
            const isSelected = !!selected[d.packageName];
            return (
              <button key={d.packageName} onClick={() => toggle(d.packageName)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 12, padding: "11px 4px", borderBottom: i < list.length - 1 ? `1px solid ${C.line}` : "none", background: "none", border: "none", cursor: "pointer", textAlign: "left" }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: C.ink, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <span style={{ fontFamily: FONT, fontWeight: 800, fontSize: 16, color: C.paper }}>{d.label.charAt(0).toUpperCase()}</span>
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: FONT, fontWeight: 700, fontSize: 14.5, color: C.ink }}>{d.label}</div>
                  <div style={{ fontFamily: FONT, fontWeight: 500, fontSize: 11.5, color: C.steel, marginTop: 1 }}>{d.packageName}</div>
                </div>
                {isSelected ? (
                  <CheckCircle2 size={24} color={C.red} strokeWidth={2.2} style={{ flexShrink: 0 }} />
                ) : (
                  <div style={{ width: 22, height: 22, borderRadius: "50%", border: `2px solid ${C.line}`, flexShrink: 0 }} />
                )}
              </button>
            );
          })}
        </div>

        <button
          onClick={() => entries.length > 0 && onImportDevice(entries.map((e) => ({ name: e.label, packageName: e.packageName })), onClose)}
          disabled={busy || entries.length === 0}
          style={{ marginTop: 14, width: "100%", height: 52, borderRadius: 16, border: "none", background: entries.length === 0 ? C.steel2 : C.red, color: C.paper, fontFamily: FONT, fontWeight: 800, fontSize: 15, cursor: entries.length === 0 ? "default" : "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, flexShrink: 0 }}
        >
          {busy && <Loader2 size={16} className="animate-spin" />}
          {entries.length === 0 ? "Select installed apps" : `Import ${entries.length} app${entries.length === 1 ? "" : "s"}`}
        </button>
      </div>
    </div>
  );
}
