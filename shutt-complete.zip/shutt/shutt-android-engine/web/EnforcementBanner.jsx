// EnforcementBanner.jsx — setup-checklist banner for the Apps tab.
// Renders NOTHING unless running inside the native app with protection
// incomplete. Paste into shutt.jsx above AppsTab, then render it as the
// first child of AppsTab's root div (see patches.md P3).
//
// Props: { status, onOpen(kind), host, onHost(h), adminActive }
//   status: result of ShuttEnforcerBridge.getStatus() (null while loading)
//   onOpen: (kind) => ShuttEnforcerBridge.openSettings(kind)
//   host/onHost: backend LAN-IP field (real devices; emulator uses 10.0.2.2)

function EnforcementBanner({ status, onOpen, host, onHost }) {
  const B = window.ShuttEnforcerBridge;
  if (!B || !B.isNative()) return null; // browser preview: invisible
  if (!status) return null;

  const needA11y = !status.accessibilityEnabled;
  const needUsage = !status.usageAccessGranted;
  const needBattery = !status.batteryExempt;
  if (!needA11y && !needUsage && !needBattery) return null; // fully protected

  const stepBtn = (label, kind, done) => (
    <button
      onClick={() => onOpen(kind)}
      style={{
        height: 44, borderRadius: 12, border: "none",
        background: done ? "#0F8A4B" : "#E01B22",
        color: "#FFFFFF", fontFamily: FONT, fontWeight: 800, fontSize: 13.5,
        cursor: "pointer", padding: "0 16px",
      }}
    >
      {done ? "✓ " : ""}{label}
    </button>
  );

  return (
    <div style={{ margin: "0 20px 14px", borderRadius: 20, background: "#141414", padding: "18px" }}>
      <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 15, color: "#FFFFFF" }}>
        {needA11y ? "Protection is off" : "Almost protected"}
      </div>
      <div style={{ fontFamily: FONT, fontWeight: 500, fontSize: 12.5, color: "#A9A6A2", marginTop: 4, lineHeight: 1.5 }}>
        {needA11y
          ? "Shutt can't block apps until you grant accessibility access. Locks are tracked, but apps will still open."
          : "Accessibility is on. Finish the remaining steps so blocking survives restarts and battery saving."}
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
        {stepBtn("Accessibility", "accessibility", status.accessibilityEnabled)}
        {stepBtn("Usage access", "usage", status.usageAccessGranted)}
        {stepBtn("Battery: don't optimize", "battery", status.batteryExempt)}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 12 }}>
        <div style={{ fontFamily: FONT, fontWeight: 700, fontSize: 12, color: "#A9A6A2", flexShrink: 0 }}>Backend:</div>
        <input
          value={host}
          onChange={(e) => onHost(e.target.value)}
          placeholder="10.0.2.2, LAN IP, or Codespaces https URL"
          style={{ flex: 1, height: 40, borderRadius: 10, border: "1px solid #2C2C2C", background: "#1F1F1F", padding: "0 12px", fontFamily: FONT, fontSize: 13, color: "#FFFFFF", outline: "none", minWidth: 0 }}
        />
      </div>
      <button
        onClick={() => onOpen("admin")}
        style={{ marginTop: 10, background: "none", border: "none", color: "#A9A6A2", fontFamily: FONT, fontWeight: 700, fontSize: 12, cursor: "pointer", padding: 0 }}
      >
        Extra: prevent uninstall (device admin, optional) →
      </button>
    </div>
  );
}
