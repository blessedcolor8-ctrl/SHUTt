# Web integration patches

> STATUS: Option A (below) is already applied in the shipped `web-app/` and
> `mobile/www/` bundles — `shutt-device-ui.js` delivers the setup checklist +
> device import with zero bundle surgery, sharing the bundle's React instance.
> Use Option B only if you are evolving `frontend/shutt.jsx` as source and
> recompiling the bundle yourself.
>
> Either way, the native engine + self-driving bridge work with no app-code
> hooks: login, locks, unlocks and logout propagate automatically.

## Option A — prebuilt (already done in this bundle, 1 min to verify)

1. `web/shutt-enforcer-bridge.js` and `web/shutt-device-ui.js` exist next to
   the bundle `index.html` (they do — check).
2. `index.html` contains, right after `<div id="root"></div>`:
   ```html
   <script src="./shutt-enforcer-bridge.js"></script>
   <script type="module" src="./shutt-device-ui.js"></script>
   ```
   (present — check). `mobile/build-www.js` copies both into the APK build.

## Option B — shutt.jsx source path (only if you recompile the bundle)

## P1 — load the bridge (REQUIRED, 2 min)

1. Copy `web/shutt-enforcer-bridge.js` into `web-app/` (same folder as its
   `index.html`). `mobile/build-www.js` copies the whole folder, so it lands
   in the APK automatically on the next `npm run cap:sync`.
2. In `web-app/index.html`, right after `<div id="root"></div>`, add:
   ```html
   <script src="./shutt-enforcer-bridge.js"></script>
   ```
   (before the `<script type="module">` block).

That's it for syncing: on-device the bridge pushes every lock change to the
native cache within ~5s of login/lock/unlock, hands the monitor its auth, and
goes quiet in the browser (all calls no-op when `window.Capacitor` is absent).

## P2 — paste the two new components (REQUIRED, 3 min)

Paste the full contents of `web/EnforcementBanner.jsx` and
`web/DeviceImportSheet.jsx` into `shutt.jsx` **directly above** this line
(shutt.jsx:886):

```jsx
function AppActionSheet({ app, onClose, onChooseShutt, onChooseSession }) {
```

They use only names already in scope (`useState`, `C`, `FONT`, `X`, `Search`,
`CheckCircle2`, `Loader2`). No imports to add.

## P3 — setup banner in AppsTab (REQUIRED, 5 min)

**3a.** shutt.jsx:1027 — extend the signature:

```jsx
// old:
function AppsTab({ apps, catalog, sessions, onChooseShutt, onChooseSession, onOpenDetail, onOpenSession, onBell, unread, onAddApp, addingApp, onImportApps, importingApps }) {
// new: append onImportDeviceApps
function AppsTab({ apps, catalog, sessions, onChooseShutt, onChooseSession, onOpenDetail, onOpenSession, onBell, unread, onAddApp, addingApp, onImportApps, importingApps, onImportDeviceApps }) {
```

**3b.** shutt.jsx:1032 — after `const [actionApp, setActionApp] = useState(null);` add:

```jsx
const [showDevice, setShowDevice] = useState(false);
const [deviceApps, setDeviceApps] = useState([]);
const [enforcerStatus, setEnforcerStatus] = useState(null);
const [backendHost, setBackendHost] = useState(() => (window.ShuttEnforcerBridge ? window.ShuttEnforcerBridge.getHost() : "10.0.2.2"));
useEffect(() => {
  let alive = true;
  const B = window.ShuttEnforcerBridge;
  if (B && B.isNative()) {
    B.getStatus().then((s) => { if (alive) setEnforcerStatus(s); }).catch(() => {});
    B.listInstalledApps().then((r) => { if (alive) setDeviceApps((r && r.apps) || []); }).catch(() => {});
  }
  return () => { alive = false; };
}, []);
```

**3c.** shutt.jsx:1042 — after `<div style={{ paddingBottom: 24 }}>` add:

```jsx
<EnforcementBanner
  status={enforcerStatus}
  onOpen={(kind) => window.ShuttEnforcerBridge && window.ShuttEnforcerBridge.openSettings(kind)}
  host={backendHost}
  onHost={(h) => { setBackendHost(h); window.ShuttEnforcerBridge && window.ShuttEnforcerBridge.setHost(h); }}
/>
```

**3d.** shutt.jsx:1059–1062 — after the "Add one by hand" button add:

```jsx
<button onClick={() => setShowDevice(true)} style={{ height: 50, borderRadius: 14, border: "1.5px solid #141414", background: "#141414", color: "#FFFFFF", fontFamily: FONT, fontWeight: 700, fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, cursor: "pointer" }}>
  <Smartphone size={17} strokeWidth={2.4} />
  On this device (real blocking)
</button>
```

(`Smartphone` is already imported from lucide-react.)

**3e.** shutt.jsx:1134–1142 — after the `{showImport && (...)}` block add:

```jsx
{showDevice && (
  <DeviceImportSheet
    deviceApps={deviceApps}
    existingNames={apps.map((a) => a.name)}
    busy={importingApps}
    onClose={() => setShowDevice(false)}
    onImportDevice={(entries, close) => onImportDeviceApps(entries, () => { setShowDevice(false); if (close) close(); })}
  />
)}
```

## P4 — device-import handler in ShuttApp (REQUIRED, 3 min)

**4a.** shutt.jsx:1827–1839 — after the whole `handleImportApps` block add:

```jsx
const handleImportDeviceApps = async (entries, closeSheet) => {
  setImportingApps(true);
  try {
    const B = window.ShuttEnforcerBridge;
    for (const e of entries) {
      try {
        await call("/apps", {
          method: "POST",
          body: {
            name: e.name,
            category: (typeof guessCategory === "function" ? guessCategory(e.name) : "Imported"),
            color: "#141414",
            iconKey: "smartphone",
          },
        });
      } catch (err) { /* name may already exist — mapping below still applies */ }
      if (B) B.saveDeviceMapping(e.name, e.packageName);
    }
    showToast(`${entries.length} app${entries.length === 1 ? "" : "s"} imported`, "Real blocking is armed for these");
    await refreshApps();
    closeSheet();
  } catch (e) {
    showError(e.message);
  } finally {
    setImportingApps(false);
  }
};
```

NOTE on `iconKey: "smartphone"`: verify `ICON_MAP` in shutt.jsx maps
`"smartphone"` (it imports `Smartphone` from lucide). If that key is absent,
use `"app-window"` (the backend default) instead.

**4b.** shutt.jsx:1951 — in the `<AppsTab ... />` invocation, append the prop:

```jsx
onImportDeviceApps={handleImportDeviceApps}
```

(string-replace `onImportApps={handleImportApps} importingApps={importingApps}`
with itself plus the new prop; in the compiled bundle the same keys appear as
`onImportApps: handleImportApps, importingApps: importingApps`.)

## P5 — strings.xml (REQUIRED for the manifest services)

In `android/app/src/main/res/values/strings.xml` add:

```xml
<string name="shutt_accessibility_description">Lets Shutt detect when a locked app is opened so it can block it until the timer ends.</string>
<string name="shutt_device_admin_description">Lets Shutt refuse uninstall while protection is on.</string>
```

## Recompile + rebuild

`shutt.jsx` edits reach the APK via the project's normal flow: recompile to
`web-app/index.html` (same process that produced it), then
`npm run cap:sync && cd android && ./gradlew assembleDebug`.
